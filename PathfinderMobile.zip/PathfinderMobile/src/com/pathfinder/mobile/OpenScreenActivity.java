package com.pathfinder.mobile;

import com.pathfinder.mobile.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class OpenScreenActivity extends Activity {
	
	public Cursor cursor;
	private ListView characterList;
	private BioTable newCharacter;
	private AbilitiesTable newCharacterAbilities;
	private SkillsTable2 mDbHelper;
	private FeatsTable2 newCharacterFeats2;
	private GearTable newCharacterGear;
	private OtherTable newCharacterOther;
	final Context context = this;
	private long idToPass;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.open_screen);
        setTitle(R.string.open_screen);
        
        newCharacter = new BioTable(this); 
        newCharacterAbilities = new AbilitiesTable(this);
        mDbHelper = new SkillsTable2(this);
        newCharacterGear = new GearTable(this);
        newCharacterOther = new OtherTable(this);
        
        newCharacterFeats2 = new FeatsTable2(this);
        
        newCharacter.open();
        newCharacterAbilities.open();
        mDbHelper.open();
        newCharacterGear.open();
        newCharacterOther.open();
        
        newCharacterFeats2.open();
        newCharacterFeats2.addFeatsList();
        
        
        Button btnNewCharacter = (Button) findViewById(R.id.new_character_button);
      
        showData();
        
        // view world click event
        btnNewCharacter.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
            	//adds a blank new character and inserts the name New Character to be modified
                long insertID = newCharacter.addBio("New Character", null, null, null, "1", null, null, null);
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), BioActivity.class);
                i.putExtra( "c_id", String.valueOf(insertID) );
                startActivity(i);
 
            }
        });
    }
    
    public void showData() {
    	
    	 characterList = (ListView) findViewById(R.id.character_list);
         Cursor cursor = newCharacter.getCursor();
         
         String[] from = { BioTable.KEY_ID, BioTable.KEY_NAME };
         int[] to = { R.id.characterID, R.id.characterView };
         SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.row , cursor, from, to);
         characterList.setAdapter(adapter); 
         
         characterList.setOnItemClickListener(new OnItemClickListener() {
        // @Override
         public void onItemClick(AdapterView<?> a, View v, int position, long id) {
        	 
        	 idToPass = id;
        	 
        	 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
     				context);
      
     			// set title
     			alertDialogBuilder.setTitle("Character Manager");
      
     			// set dialog message
     			alertDialogBuilder
     				.setMessage("Would you like to Edit or Delete this character?")
     				.setCancelable(false)
     				.setPositiveButton("Edit",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						
     						 // Launching Bio Screen
     						Intent i = new Intent(getApplicationContext(), BioActivity.class);
     			            i.putExtra( "c_id", idToPass );
     			            startActivity(i);
     					}
     				  })
     				.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						// if this button is clicked, just close
     						// the dialog box and do nothing
     						dialog.cancel();
     					}
     				})
     				.setNeutralButton("Delete",new DialogInterface.OnClickListener() {
         					public void onClick(DialogInterface dialog,int id) {
         					
         						String s = String.valueOf(idToPass);
         						newCharacterAbilities.deleteAbilities(s);
         						newCharacter.deleteBio(s);
         						mDbHelper.deleteSkills(s);
         						newCharacterFeats2.deleteAllFeats(s);
         						newCharacterGear.deleteAllGear(s);
         						newCharacterOther.deleteOther(s);
         				       
         						showData();
         						dialog.cancel();
         					}
     				});
      
     				// create alert dialog
     				AlertDialog alertDialog = alertDialogBuilder.create();
      
     				// show it
     				alertDialog.show();
            
         }
         });
    	
    }
    
    
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		newCharacter.open();
        newCharacterAbilities.open();
        mDbHelper.open();
        newCharacterGear.open();
        newCharacterOther.open();

        newCharacterFeats2.open();

		showData();
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        newCharacter.close();
        newCharacterAbilities.close();
        mDbHelper.close();
        newCharacterGear.close();
        newCharacterOther.close();
        
        newCharacterFeats2.close();

    }


}
