package com.pathfinder.mobile;

import com.pathfinder.mobile.R;

import android.net.Uri;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActionBar.OnNavigationListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class GearActivity extends Activity {
	
	public Cursor cursor;
	private ListView gearList;
	private GearTable newGear;
	final Context context = this;
	private String c_id;
	private String clickID;
	private OnNavigationListener mOnNavigationListener; //navigation listener
	private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gear_page);
        setTitle(R.string.gear_screen);
        
        
       //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
                
        newGear = new GearTable(this); 
        newGear.open();
        
        Button btnNewCharacter = (Button) findViewById(R.id.add_feat_button);
        Button btnNextScreen = (Button) findViewById(R.id.next_button);
        
        if (newGear.characterRecordExists(c_id))
        {
        	showData();
        }
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
                    closeConnections();
            	}
            	
            	
                return false;
            }
        };
        
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);
        
        // view world click event
        btnNewCharacter.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
            	//adds a blank new character and inserts the name New Character to be modified
                long insertID = newGear.addGear(c_id, "New Gear");
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), GearEdit.class);
                i.putExtra( "c_id", c_id );
                i.putExtra( "id", insertID );
                startActivity(i);
                finish();
 
            }
        });
        
        // view world click event
        btnNextScreen.setOnClickListener(new View.OnClickListener() {
        
            @Override
            public void onClick(View view) {
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
 
            }
        });
    }
    
    public void showData() {
    	
    	 gearList = (ListView) findViewById(R.id.gear_list);
         Cursor cursor = newGear.getCursor(c_id);
                  
         String[] from = { GearTable.KEY_ID, GearTable.KEY_GEAR };
         int[] to = { R.id.characterID, R.id.itemGear };
         SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.gearrow , cursor, from, to);
         gearList.setAdapter(adapter); 
         
         gearList.setOnItemClickListener(new OnItemClickListener() {
         // @Override
         public void onItemClick(AdapterView<?> a, View v, int position, long id) {
        	 
        	 clickID = String.valueOf(id);
        	         	 
        	 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
     				context);
      
     			// set title
     			alertDialogBuilder.setTitle("Gear Manager");
      
     			// set dialog message
     			alertDialogBuilder
     				.setMessage("Would you like to Edit or Delete this gear?")
     				.setCancelable(false)
     				.setPositiveButton("Edit",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						
     						 // Launching Bio Screen
     						Intent i = new Intent(getApplicationContext(), GearEdit.class);
     			            i.putExtra( "id", clickID );
     			            i.putExtra( "c_id", c_id );
     			            startActivity(i);
     			            finish();
     			            
     					}
     				  })
     				.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						// if this button is clicked, just close
     						// the dialog box and do nothing
     						dialog.cancel();
     					}
     				})
     				.setNeutralButton("Delete",new DialogInterface.OnClickListener() {
         					public void onClick(DialogInterface dialog,int id) {
         					
         						newGear.deleteGear(clickID);
         						showData();
         						dialog.cancel();
         					}
     				});
      
     				// create alert dialog
     				AlertDialog alertDialog = alertDialogBuilder.create();
      
     				// show it
     				alertDialog.show();
            
         }
         });
    	
    }
    
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
        newGear.open();
        if (newGear.characterRecordExists(c_id))
        {
        	showData();
        }
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        closeConnections();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        closeConnections();
    }
    
    protected void closeConnections()
    {
    	newGear.close();
    }

}
