package com.pathfinder.mobile;

import java.util.ArrayList;

import com.pathfinder.mobile.R;

import android.net.Uri;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.ActionBar.OnNavigationListener;
import android.app.Activity;
import android.content.Intent;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AbilityActivity extends Activity {
	
	private ArrayList<String> raceList = new ArrayList<String>();
	private ArrayList<String> classList = new ArrayList<String>();
	String[] characterAbilities; //Save abilities prior to modifiers by race
	String[] characterBio; //Keeps track of biographical info
	String initialValue = "0"; //String to initialize new character abilities record
	private AbilitiesTable characterAttributes;//stores abilities
    private BioTable character; //stores race and class
    private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abilities_main);
        setTitle(R.string.abilities_screen);
        characterAttributes = new AbilitiesTable(this); //open Abilities database
        character = new BioTable(this); //open Bio database
        
        characterAttributes.open();
        character.open();
        
        //add items to raceList
        raceList.add("Dwarf");
        raceList.add("Elf");
        raceList.add("Garden Gnome");
        raceList.add("Half-Elf");
        raceList.add("Half-Orc");
        raceList.add("Halfling");
        raceList.add("Human");
        
        //add items to classList
        classList.add("Barbarian");
        classList.add("Bard");
        classList.add("Cleric");
        classList.add("Druid");
        classList.add("Fighter");
        classList.add("Monk");
        classList.add("Paladin");
        classList.add("Ranger");
        classList.add("Rogue");
        classList.add("Sorcerer");
        classList.add("Wizard");
       
        //get the id from previous screen
        final String c_id = getIntent().getExtras().get("c_id").toString();
        
        //instantiate abilities fields
        final EditText strength = (EditText) findViewById(R.id.strength_textfield);
        final EditText dexterity = (EditText) findViewById(R.id.dexterity_textfield);
        final EditText constitution = (EditText) findViewById(R.id.constitution_textfield);
        final EditText intelligence = (EditText) findViewById(R.id.intelligence_textfield);
        final EditText wisdom = (EditText) findViewById(R.id.wisdom_textfield);
        final EditText charisma = (EditText) findViewById(R.id.charisma_textfield);
        final Spinner raceSpinner = (Spinner) findViewById(R.id.race_spinner);
        final Spinner classSpinner = (Spinner) findViewById(R.id.class_spinner);
                	
    	// get abilities from database and populate screen
    	characterAbilities = characterAttributes.getAbilities(c_id); //Store original
    	strength.setText(characterAbilities[0]);
    	dexterity.setText(characterAbilities[1]);
    	constitution.setText(characterAbilities[2]);
    	intelligence.setText(characterAbilities[3]);
    	wisdom.setText(characterAbilities[4]);
    	charisma.setText(characterAbilities[5]);
        
    	//get attributes from Bio Table
    	characterBio = character.getBio(c_id);
    	int racePosition = raceList.indexOf(characterBio[1]);
    	raceSpinner.setSelection(racePosition);
    	
    	int classPosition = classList.indexOf(characterBio[2]);
    	classSpinner.setSelection(classPosition);
 
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
                    closeConnections();
            	}
            	
            	
                return false;
            }
        };
 
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);
        
        //The roll button
        Button Roll = (Button) findViewById(R.id.Roll);
        
        //create the text boxes for roll values at top of interface
        final TextView roll1 = (TextView) findViewById(R.id.roll1);
        final TextView roll2 = (TextView) findViewById(R.id.roll2);
        final TextView roll3 = (TextView) findViewById(R.id.roll3);
        final TextView roll4 = (TextView) findViewById(R.id.roll4);
        final TextView roll5 = (TextView) findViewById(R.id.roll5);
        final TextView roll6 = (TextView) findViewById(R.id.roll6);
                
        Roll.setOnClickListener(new View.OnClickListener() {
       	 
            @Override
            public void onClick(View view) {
            	
                // rolls the dice and enters into textviews
            	roll1.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	roll2.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	roll3.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	roll4.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	roll5.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	roll6.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	
            }
        });
        
        raceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            
        	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Object item = parent.getItemAtPosition(pos);
            }
            
        	public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        
       classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            
        	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Object item = parent.getItemAtPosition(pos);
            }
            
        	public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        
        Button btnSave = (Button) findViewById(R.id.save_button); //save button
   	 
        // save attributes
        btnSave.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View view) {
            	
            	//save core attributes unmodified by race
            	characterAttributes.updateAbilities(c_id, strength.getText().toString(), dexterity.getText().toString(), 
            			constitution.getText().toString(), intelligence.getText().toString(),
            			wisdom.getText().toString(), charisma.getText().toString());
            	
            	//save Bio Info
            	character.updateAbilitiesBio( c_id, raceSpinner.getSelectedItem().toString(), classSpinner.getSelectedItem().toString() );
            	
            	Toast.makeText(getApplicationContext(), "Information Saved", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
 
            }
        });

    } //end on create method
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		characterAttributes.open();
        character.open();
	}
	
	@Override
    protected void onPause() {
        super.onPause();
        closeConnections();
    }
	
	protected void closeConnections()
    {
		characterAttributes.close();
        character.close();
    }
	
} //end Ability Activity
