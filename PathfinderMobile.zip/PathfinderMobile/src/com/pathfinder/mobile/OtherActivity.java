package com.pathfinder.mobile;

import java.util.ArrayList;

import com.pathfinder.mobile.R;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.OnNavigationListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class OtherActivity extends Activity {
	
	private ArrayList alignmentList = new ArrayList();
	private TextView roll1;
	private EditText hitPoints;
	private EditText armorClass;
	private EditText initiativeModifier;
	private EditText experiencePoints;
	private EditText level;
	private Spinner alignmentSpinner;
	private Spinner dieSpinner;
	private Button saveButton;
	private Button rollButton;
	private BioTable characterBio;
	private OtherTable characterOther;
	private String c_id;
	private String[] characterOtherAtt; //Save abilities prior to modifiers by race
	private String[] characterBioAtt; //Keeps track of biographical info
	private String rollOption;
	private OnNavigationListener mOnNavigationListener; //navigation listener
	private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other_page);
        setTitle(R.string.other_screen);
        
        characterBio = new BioTable(this);
        characterOther = new OtherTable(this);
        
        characterBio.open();
        characterOther.open();
        
        //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
        
        
        alignmentList.add("Chaotic Evil");
        alignmentList.add("Chaotic Good");
        alignmentList.add("Chaotic Neutral");
        alignmentList.add("Lawful Evil");
        alignmentList.add("Lawful Good");
        alignmentList.add("Lawful Neutral");
        alignmentList.add("Neutral Evil");
        alignmentList.add("Neutral Good");
        alignmentList.add("Neutral");
        
        //instantiate other fields in xml
        roll1 = (TextView) findViewById(R.id.roll1);
        hitPoints = (EditText) findViewById(R.id.hitpoints_textfield);
        armorClass = (EditText) findViewById(R.id.armor_textfield);
        initiativeModifier = (EditText) findViewById(R.id.initiative_modifier_textfield);
        experiencePoints = (EditText) findViewById(R.id.experience_points_textfield);
        level = (EditText) findViewById(R.id.level_textfield);
        alignmentSpinner = (Spinner) findViewById(R.id.alignment_spinner);
        dieSpinner = (Spinner) findViewById(R.id.die_spinner);
        saveButton = (Button) findViewById(R.id.save_button);
        rollButton = (Button) findViewById(R.id.Roll);
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
                    closeConnections();
            	}
            	
            	
                return false;
            }
        };
        
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);
        
        alignmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            
        	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Object item = parent.getItemAtPosition(pos);
            }
            
        	public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        
        dieSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            
        	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Object item = parent.getItemAtPosition(pos);
            }
            
        	public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        
        // save attributes
        saveButton.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View view) {
            	
            	//save bio data
            	characterBio.updateOtherBio(c_id, level.getText().toString(), alignmentSpinner.getSelectedItem().toString());
            	
            	//save Other Info
            	characterOther.updateOther( c_id, hitPoints.getText().toString(), armorClass.getText().toString(),
            			initiativeModifier.getText().toString(), experiencePoints.getText().toString() );
            	
            	Toast.makeText(getApplicationContext(), "Information Saved", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                startActivity(i);
 
            }
        });
        
        // roll dice
        rollButton.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View view) {
            	
            	String roll = dieSpinner.getSelectedItem().toString();
            	
            	// rolls the dice and enters into textviews
            	// roll1.setText(Integer.toString(Dice.classicAbilitiesRoll()));
            	
            	if (roll.equals("d4"))
            	{
            		roll1.setText(Integer.toString(Dice.fourSidedDie(1)));
            	}
            	else if (roll.equals("d6"))
            	{
            		roll1.setText(Integer.toString(Dice.sixSidedDie(1)));
            	}
            	else if (roll.equals("d8"))
            	{
            		roll1.setText(Integer.toString(Dice.eightSidedDie(1)));
            	}
            	else if (roll.equals("d10"))
            	{
            		roll1.setText(Integer.toString(Dice.tenSidedDie(1)));
            	}
            	else if (roll.equals("d12"))
            	{
            		roll1.setText(Integer.toString(Dice.twelveSidedDie(1)));
            	}
            	else if (roll.equals("d20"))
            	{
            		roll1.setText(Integer.toString(Dice.twentySidedDie(1)));
            	}
 
            }
        });
                
       //get bio records if they exist
        if (characterBio.recordExists(c_id))
        {        	
        	//If bio data for the character exist, get them from database and populate screen
        	
        	characterBioAtt = characterBio.getBio(c_id); //Store original
        	level.setText(characterBioAtt[4]);
        	int alignmentPosition = alignmentList.indexOf(characterBioAtt[3]);
        	alignmentSpinner.setSelection(alignmentPosition);
 
        }
        if (characterOther.recordExists(c_id))
        {        	
        	//If other attributes for the character exist, get them from database and populate screen
        	
        	characterOtherAtt = characterOther.getOther(c_id); //Store original
        	hitPoints.setText(characterOtherAtt[1]);
        	armorClass.setText(characterOtherAtt[2]);
        	initiativeModifier.setText(characterOtherAtt[3]);
        	experiencePoints.setText(characterOtherAtt[4]);
        }
        else
        {
        	//intialize table and Other attributes array for update
        	characterOther.addOther( c_id, "0", "0", "0", "0" );
        	characterOtherAtt = characterOther.getOther(c_id); //Store original
        }
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		characterBio.open();
        characterOther.open();
	}
	
	@Override
    protected void onPause() {
        super.onPause();
        closeConnections();
    }
	
	protected void closeConnections()
    {
		characterBio.close();
        characterOther.close();
    }

}
