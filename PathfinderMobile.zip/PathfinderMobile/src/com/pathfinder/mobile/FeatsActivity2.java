package com.pathfinder.mobile;

import com.pathfinder.mobile.R;

import android.net.Uri;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActionBar.OnNavigationListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class FeatsActivity2 extends Activity {
	
	public Cursor cursor;
	private ListView featsList;
	private FeatsTable2 newFeats;
	final Context context = this;
	private String c_id;
	private String clickID;
	private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feats_page2);
        setTitle(R.string.feats_screen);
        
       //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
        
        newFeats = new FeatsTable2(this); 
        newFeats.open();
        
ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
                    closeConnections();
            	}
            	
            	
                return false;
            }
        };
 
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);
        
        Button btnMyFeats = (Button) findViewById(R.id.myfeats_button);
        Button btnNextScreen = (Button) findViewById(R.id.next_button);
        
        showData();
        
     // view world click event
        btnMyFeats.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), MyFeatsActivity.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
                finish();
 
            }
        });
        
        // view world click event
        btnNextScreen.setOnClickListener(new View.OnClickListener() {
        
            @Override
            public void onClick(View view) {
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), GearActivity.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
 
            }
        });
    }
    
    public void showData() {
    	
    	 featsList = (ListView) findViewById(R.id.feats_list);
         Cursor cursor = newFeats.getFeatsCursor();
         
         String[] from = { FeatsTable2.KEY_ID, FeatsTable2.KEY_NAME, FeatsTable2.KEY_DESCRIPTION };
         int[] to = { R.id.featID, R.id.featName, R.id.featDescription };
         SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.featsrow2 , cursor, from, to);
         featsList.setAdapter(adapter); 
         
         featsList.setOnItemClickListener(new OnItemClickListener() {
         // @Override
         public void onItemClick(AdapterView<?> a, View v, int position, long id) {
        	 
        	 clickID = String.valueOf(id);
        	         	 
        	 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
     				context);
      
     			// set title
     			alertDialogBuilder.setTitle("Feats Manager");
      
     			// set dialog message
     			alertDialogBuilder
     				.setMessage("Would you like to Add this feat?")
     				.setCancelable(false)
     				.setPositiveButton("Add",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						
     						newFeats.addFeat(c_id, clickID);
     						
     						 // Launching MyFeats Screen
     						Intent i = new Intent(getApplicationContext(), MyFeatsActivity.class);
     			            i.putExtra( "id", clickID );
     			            i.putExtra( "c_id", c_id );
     			            startActivity(i);
     			            finish();
     			            
     					}
     				  })
     				.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						// if this button is clicked, just close
     						// the dialog box and do nothing
     						dialog.cancel();
     					}
     				});
      
     				// create alert dialog
     				AlertDialog alertDialog = alertDialogBuilder.create();
      
     				// show it
     				alertDialog.show();
            
         }
         });
    	
    }
    
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		newFeats.open();
		if (newFeats.characterRecordExists(c_id))
        {
        	showData();
        }
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        closeConnections();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        closeConnections();
    }
    
    protected void closeConnections()
    {
    	newFeats.close();
    }


}
