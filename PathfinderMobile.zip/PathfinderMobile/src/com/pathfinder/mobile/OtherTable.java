package com.pathfinder.mobile;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class OtherTable extends SQLiteOpenHelper {
	
	 // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "OtherInfo";
 
    // Size table name
    private static final String TABLE_OTHER = "OtherTable";
 
    // Size Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_C_ID = "c_id";
    private static final String KEY_HP = "hp";
    private static final String KEY_ARMOR_CLASS = "armor_class";
    private static final String KEY_INITIATIVE_MOD = "initiative_modifier";
    private static final String KEY_EXPERIENCE_POINTS = "experience_points";
    
    // database for our class
    private SQLiteDatabase db;
    
    public OtherTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub

    }
    
	public void onCreate(SQLiteDatabase db) {
			
			String CREATE_OTHER_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_OTHER + " ("
					+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
					+ KEY_C_ID + " INTEGER, "
					+ KEY_HP + " INTEGER, "
					+ KEY_ARMOR_CLASS + " INTEGER, "
					+ KEY_INITIATIVE_MOD  + " INTEGER, "
					+ KEY_EXPERIENCE_POINTS + " INTEGER " + ")";
	        db.execSQL(CREATE_OTHER_TABLE);
			
		}
	
	 // Upgrading database
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	    // Drop older Abilities table if existed
	    db.execSQL("DROP TABLE IF EXISTS " + TABLE_OTHER);
	
	    // Create tables again
	    onCreate(db);
	    
	}
	
	//open db
	public SQLiteDatabase open() throws SQLException
	{
		return db = this.getWritableDatabase();
	}
	
	//close db
	 public void close()
	 {
		 db.close();
		 
	 }
	
	public long addOther(String c_id, String hp, String armor_class, String initiative_mod, String experience_points) {
			   
		   ContentValues values = new ContentValues();
		   values.put(KEY_C_ID, c_id);
		   values.put(KEY_HP, hp);
		   values.put(KEY_ARMOR_CLASS, armor_class); 
		   values.put(KEY_INITIATIVE_MOD, initiative_mod); 
		   values.put(KEY_EXPERIENCE_POINTS, experience_points);
		  
		   // Inserting Row
		   long insertID = db.insert(TABLE_OTHER, null, values);
		   
		   return insertID;
		
	}
	
	public String[] getOther(String characterID) {
	    
		String[] characterOther = new String[5];
	    
	    Cursor cursor = db.query(TABLE_OTHER, new String[] { KEY_C_ID, KEY_HP, KEY_ARMOR_CLASS, KEY_INITIATIVE_MOD, 
	    		KEY_EXPERIENCE_POINTS }, KEY_C_ID + "=?",
	            new String[] { characterID }, null, null, null, null);
	    
	    if (cursor.moveToFirst())
	    {
	        //enter character attributes into string
	        for (int i = 0; i < characterOther.length; i++ )
	        {
	        	characterOther[i] = cursor.getString(i);
	        }
	    }
	    
	   return characterOther;
	            
	}
	
	//update Other
	public int updateOther(String c_id, String hp, String armor_class, String initiative_mod, String experience_points) {
	     
	    ContentValues values = new ContentValues();
	    values.put(KEY_HP, hp);
		values.put(KEY_ARMOR_CLASS, armor_class); 
		values.put(KEY_INITIATIVE_MOD, initiative_mod); 
		values.put(KEY_EXPERIENCE_POINTS, experience_points);
	    
	    // updating row
	    return db.update(TABLE_OTHER, values, KEY_C_ID + " = ?",
	            new String[] { c_id });
	}
	
	//delete Other
	public void deleteOther(String c_id) {
	    
		if (recordExists(c_id))
		{
	        db.delete(TABLE_OTHER, KEY_C_ID + " = ?",
	                new String[] { c_id });
		}
	}
	
	public boolean recordExists(String c_id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_OTHER +" WHERE c_id=?", 
		        new String[] { c_id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}

}


