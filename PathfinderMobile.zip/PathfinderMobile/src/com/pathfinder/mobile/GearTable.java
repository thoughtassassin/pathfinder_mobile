package com.pathfinder.mobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

public class GearTable extends SQLiteOpenHelper {
	
    // All Static variables
    // Database Version
    public static final int DATABASE_VERSION = 1;
 
    // Database Name
    public static final String DATABASE_NAME = "GearInfo";
 
    // Gear table name
    public static final String TABLE_GEAR = "GearTable";
 
    //Gear Table Columns names
    public static final String KEY_ID = "_id";
    public static final String KEY_C_ID = "c_id";
    public static final String KEY_GEAR = "gear";
    
    //database for our class
    private SQLiteDatabase db;
    
	public GearTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		String CREATE_GEAR_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_GEAR + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_C_ID + " INTEGER,"
                + KEY_GEAR + " TEXT " + ")";
        db.execSQL(CREATE_GEAR_TABLE);
		
	}

	 // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GEAR);
 
        // Create tables again
        onCreate(db);
    }
    
    //open db
  	public SQLiteDatabase open() throws SQLException
  	{
  		return db = this.getWritableDatabase();
  	}
  	
  	//close db
  	 public void close()
  	 {
  		 db.close();
  		 
  	 }
    
    // Adding bio for character
    public long addGear(String c_id, String gear) {
    	    	   
    	   ContentValues values = new ContentValues();
    	   values.put(KEY_C_ID, c_id); // Character Name
    	   values.put(KEY_GEAR, gear); // Character Race   
    	 
    	   // Inserting Row
    	   long insertID = db.insert(TABLE_GEAR, null, values);
    	   
    	   return insertID;
    	
    }
     
    // Getting Character Gear Attributes
    public String[] getAllGear(String characterID) {
        
    	String[] gears = new String[2]; //string to get all character attributes
        
        Cursor cursor = db.query(TABLE_GEAR, new String[] { KEY_C_ID, KEY_GEAR }, KEY_ID + "=?",
                new String[] { characterID }, null, null, null, null);
        
        if (cursor.moveToFirst())
        {
	        //enter character attributes into string
	        for (int i = 0; i < gears.length; i++ )
	        {
	        	gears[i] = cursor.getString(i);
	        }
        }
 	   
       return gears;
                
    }
    
 // Getting Character Gear Attributes
    public String[] getSingleGear(String id) {
        
    	String[] gear = new String[2]; //string to get all character attributes
        
        Cursor cursor = db.query(TABLE_GEAR, new String[] { KEY_C_ID, KEY_GEAR }, KEY_ID + "=?",
                new String[] { id }, null, null, null, null);
        
        if (cursor.moveToFirst())
        {
	        //enter character attributes into string
	        for (int i = 0; i < gear.length; i++ )
	        {
	        	gear[i] = cursor.getString(i);
	        }
        }
 	   
       return gear;
                
    }
	
    public int updateGear( String id, String gear ) {
            
        ContentValues values = new ContentValues();
        values.put(KEY_ID, id);
        values.put(KEY_GEAR, gear);
     
        // updating row
        return db.update(TABLE_GEAR, values, KEY_ID + " = ?",
                new String[] { id });
    }
    
    
    //delete Gear
    public void deleteGear(String id) {
        
    	if (recordExists(id))
    	{
	        db.delete(TABLE_GEAR, KEY_ID + " = ?",
	                new String[] { id });
    	}
    }
    
    //delete all gear
    public void deleteAllGear(String c_id) {
        
    	if (characterRecordExists(c_id))
    	{
	        db.delete(TABLE_GEAR, KEY_C_ID + " = ?",
	                new String[] { c_id });
    	}
    }
    
    //Cursor to retrive existing characters
    public Cursor getCursor(String c_id)
    {
    	
    	SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
    	
    	queryBuilder.setTables(TABLE_GEAR);
    	String[] asColumnsToReturn = new String[] { KEY_ID, KEY_GEAR };
    	
    	Cursor mCursor = queryBuilder.query(db, asColumnsToReturn, KEY_C_ID + "=" + c_id, null, null, null, "gear ASC");
    	
    	return mCursor;
    }
    
    public boolean recordExists(String id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_GEAR +" WHERE _id=?", 
		        new String[] { id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}
    
    public boolean characterRecordExists(String id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_GEAR +" WHERE c_id=?", 
		        new String[] { id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}

}
