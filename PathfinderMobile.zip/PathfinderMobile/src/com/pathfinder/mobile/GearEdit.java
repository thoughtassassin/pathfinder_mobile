package com.pathfinder.mobile;

import com.pathfinder.mobile.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GearEdit extends Activity {
	
	private GearTable gear = new GearTable(this);
	private String id;
	private String c_id;
	private EditText gear_edit;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gear_edit);
        setTitle(R.string.edit_gear);
        
        //get the id from previous screen
        id = getIntent().getExtras().get("id").toString();
        c_id = getIntent().getExtras().get("c_id").toString();
        
        gear.open();
    
       //get the id from previous screen
       final String id = getIntent().getExtras().get("id").toString();
       String[] gearToEdit = gear.getSingleGear(id);
        
        gear_edit = (EditText) findViewById(R.id.gear_edit);

        gear_edit.setText(gearToEdit[1]);
        
        Button saveCharacter = (Button) findViewById(R.id.save_button);
        
        // view world click event
        saveCharacter.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
            	//adds a blank new gear and inserts the name New Character to be modified
            	gear.updateGear(id, gear_edit.getText().toString());
            	Toast.makeText(getApplicationContext(), "Information Updated", Toast.LENGTH_SHORT).show();
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), GearActivity.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
                finish();
 
            }
        });
    };
    
    protected void onResume() {
    	super.onResume();
        gear.open();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        gear.close();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        gear.close();
    }

}
