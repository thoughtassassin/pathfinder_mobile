package com.pathfinder.mobile;

import java.util.ArrayList;
import java.util.List;
 
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.pathfinder.mobile.R;
 
import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.app.ActionBar.OnNavigationListener;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
 
public class UpdatePositionActivity extends Activity {
 
	private EditText txtXPos;
	private EditText txtYPos;
    private Button btnEnter;
    private Button btnPosition;
    private Button btnExit;
    private String c_id;
    private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };
 
    // Progress Dialog
    private ProgressDialog pDialog;
 
    // JSON parser class
    JSONParser jsonParser = new JSONParser();
 
    // url to update product
    private static final String url_update_position = "http://www.thoughtassassin.com/pathfinder/update_position.php";
 
    // url to delete product
    private static final String url_delete_player = "http://www.thoughtassassin.com/pathfinder/delete_player.php";
 
    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_C_ID = "c_id";
    private static final String TAG_X = "x";
    private static final String TAG_Y = "y";
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gameboard);
        
        //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
        
        // position button
        btnPosition = (Button) findViewById(R.id.position_button);
        
        // position button
        btnExit = (Button) findViewById(R.id.exit_button);
        
        //x position edit text
        txtXPos = (EditText) findViewById(R.id.x_pos_editname);
        
        //x position edit text
        txtYPos = (EditText) findViewById(R.id.y_pos_editname);
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
            	}
            	
            	
                return false;
            }
        };
 
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);
 
        // Move button click event
        btnPosition.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View arg0) {
                // deleting product in background thread
                new EditPosition().execute();
            }
        });
        
        // Exit button click event
        btnExit.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View arg0) {
                // deleting product in background thread
            	new LeaveBoard().execute();
            }
        });
 
    }
 
    
    /**
     * Background Async Task to Edit Position
     * */
    class EditPosition extends AsyncTask<String, String, String> {
 
        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UpdatePositionActivity.this);
            pDialog.setMessage("Moving Player ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }
 
        /**
         * Saving product
         * */
        protected String doInBackground(String... args) {
 
            // getting updated data from EditTexts
            String x_pos = txtXPos.getText().toString();
          // getting updated data from EditTexts
            String y_pos = txtYPos.getText().toString();
            
            int success;
            try {
	            // Building Parameters
	            List<NameValuePair> params = new ArrayList<NameValuePair>();
	            params.add(new BasicNameValuePair(TAG_C_ID, c_id));
	            params.add(new BasicNameValuePair(TAG_X, x_pos));
	            params.add(new BasicNameValuePair(TAG_Y, y_pos));
	        
	            // sending modified data through http request
	            // Notice that update product url accepts POST method
	            JSONObject json = jsonParser.makeHttpRequest(url_update_position,
	                    "POST", params);
            
                success = json.getInt(TAG_SUCCESS);
 
                if (success == 1) {
                	// successfully received position details
                	// check your log for json response
                } else {
                    // failed to update position
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
 
            return null;
        }
 
        /**
         * After completing background task Dismiss the progress dialog
         * **/
        protected void onPostExecute(String file_url) {
            // dismiss the dialog once position updated
            pDialog.dismiss();
        }
    }
 
    /*****************************************************************
     * Background Async Task to Leave Board
     * */
    class LeaveBoard extends AsyncTask<String, String, String> {
 
        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UpdatePositionActivity.this);
            pDialog.setMessage("Player Exiting...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }
 
        /**
         * Deleting product
         * */
        protected String doInBackground(String... args) {
 
            // Check for success tag
            int success;
            try {
                // Building Parameters
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("c_id", c_id));
 
                // getting product details by making HTTP request
                JSONObject json = jsonParser.makeHttpRequest(
                        url_delete_player, "POST", params);
 
                // check your log for json response
 
                // json success tag
                success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
              
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
 
            return null;
        }
 
        /**
         * After completing background task Dismiss the progress dialog
         * **/
        protected void onPostExecute(String file_url) {
            // dismiss the dialog once product deleted
            pDialog.dismiss();
 
        }
 
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        
        if (pDialog != null)
        {
        	pDialog.dismiss();
        }
    }
    
	
}

