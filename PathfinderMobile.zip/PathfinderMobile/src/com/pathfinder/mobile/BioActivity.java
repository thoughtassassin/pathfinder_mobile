package com.pathfinder.mobile;

import com.pathfinder.mobile.R;

import android.net.Uri;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.OnNavigationListener;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

public class BioActivity extends Activity {
	
	private BioTable character = new BioTable(this);
	private AbilitiesTable characterAttributes = new AbilitiesTable(this);//stores abilities
	String[] characterAbilities; //Save abilities prior to modifiers by race
	String initialValue = "0"; //String to initialize new character abilities record
    private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bios_main);
        setTitle(R.string.bio_screen);
        character.open();
        characterAttributes.open();
        
        //get the id from previous screen
        final String c_id = getIntent().getExtras().get("c_id").toString();
        
        if (!characterAttributes.recordExists(c_id))
        {        	
        	//Initialize abilities table if record does not exist
        	characterAttributes.addAbilities(c_id, initialValue, initialValue, 
        			initialValue, initialValue, initialValue, initialValue);
        	
        }
    
       String[] characterBio = character.getBio(c_id);
        
        for (int i=0; i < characterBio.length; i++)
        {
        	if(characterBio[i] == null)
        	{
        		continue;
        	}
        	
        }
        
        final EditText nameField = (EditText) findViewById(R.id.name_editname);
        final MultiAutoCompleteTextView textArea = (MultiAutoCompleteTextView) findViewById(R.id.multiAutoCompleteBackground);
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
                    closeConnections();
            	}
            	
            	
                return false;
            }
        };
 
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);

        nameField.setText(characterBio[0]);
        textArea.setText(characterBio[6]);
        
        Button saveCharacter = (Button) findViewById(R.id.save_button);
        
        // view world click event
        saveCharacter.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
            	//adds a blank new character and inserts the name New Character to be modified
            	character.updateBio(c_id, nameField.getText().toString(), textArea.getText().toString());
            	Toast.makeText(getApplicationContext(), "Information Updated", Toast.LENGTH_SHORT).show();
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                i.putExtra( "c_id", String.valueOf( c_id ) );
                startActivity(i);
 
            }
        });
    };
    
    protected void onResume() {
    	super.onResume();
        character.open();
        characterAttributes.open();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        closeConnections();
    }
    
    protected void closeConnections()
    {
    	character.close();
        characterAttributes.close();
    }

}
