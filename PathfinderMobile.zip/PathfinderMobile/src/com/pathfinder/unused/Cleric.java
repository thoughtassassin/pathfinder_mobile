package com.pathfinder.unused;

public class Cleric extends ProClass {
	
	protected String[][] clericAlignment;
	
	public Cleric()
	{
		super();
		this.clericAlignment = new String[][] {
				{"Erastil","","","","","","Neutral Good","","Lawful Neutral","Lawful Good"},
				{"Iomedae","","","","","","Neutral Good","","Lawful Neutral","Lawful Good"},
				{"Torag","","","","","","Neutral Good","","Lawful Neutral","Lawful Good"},
				{"Sarenrae","","","Chaotic Good","","Neutral","Neutral Good","","","Lawful Good"},
				{"Shelyn","","","Chaotic Good","","Neutral","Neutral Good","","","Lawful Good"},
				{"Desna","","Chaotic Neutral","Chaotic Good","","","Neutral Good","","",""},
				{"Cayden Cailean","","Chaotic Neutral","Chaotic Good","","","Neutral Good","","",""},
				{"Abadar","","","","","Neutral","","Lawful Evil","Lawful Neutral","Lawful Good"},
				{"Irori","","","","","Neutral","","Lawful Evil","Lawful Neutral","Lawful Good"},
				{"Gozreh","","Chaotic Neutral","","Neutral Evil","Neutral","Neutral Good","","Lawful Neutral",""},
				{"Pharasma","","Chaotic Neutral","","Neutral Evil","Neutral","Neutral Good","","Lawful Neutral",""},
				{"Nethys","","Chaotic Neutral","","Neutral Evil","Neutral","Neutral Good","","Lawful Neutral",""},
				{"Gorum","Chaotic Evil","Chaotic Neutral","Chaotic Good","","Neutral","","","",""},
				{"Calistria","Chaotic Evil","Chaotic Neutral","Chaotic Good","","Neutral","","","",""},
				{"Asmodeus","","","","Neutral Evil","","","Lawful Evil","Lawful Neutral",""},
				{"Zon-Kuthon","","","","Neutral Evil","","","Lawful Evil","Lawful Neutral",""},
				{"Urgathoa","Chaotic Evil","","","Neutral Evil","Neutral","","Lawful Evil","",""},
				{"Norgorber","Chaotic Evil","","","Neutral Evil","Neutral","","Lawful Evil","",""},
				{"Lamashtu","Chaotic Evil","Chaotic Neutral","","Neutral Evil","","","","",""},
				{"Rovagug","Chaotic Evil","Chaotic Neutral","","Neutral Evil","","","","",""}
		 };
		this.hitDie = 8;
		this.skills= new String[] {"Appraise","Craft","Diplomacy","Heal","Knowledge-Arcana","Knowledge-History",
				"Knowledge-Nobility","Knowledge-Planes","Knowledge-Religion","Linguistics",
				"Profession","Sense Motive","Spellcraft"};
		this.skillRanks = 2;
		
	}

}
