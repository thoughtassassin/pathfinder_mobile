  package com.pathfinder.unused;

public class Dwarf extends Race{
	 
	public Dwarf(){
				super();
				this.size ="medium";
				this.abilityBonus = new String[] { "+2 Constitution", "+2 Wisdom", "+2 Charisma" };
				this.sizeBonus = new String[] { "Base Speed 30 ft.", "no bonuses, no penalties" };
				this.racialBonus = new String[] { "+4 dodge bonus to AC against monsters of giant subtype", "+2 bonus to Appraise skill checks if appraising nonmagical items with metal and/or gems", "+1 racial bonus on attack rolls against humanoid creatures of the orc and goblinoid subtypes", "+4 racial bonus to their Combat Maneuver Defense when resisting a bull rush or trip attempt while standing on the ground", "+2 bonus on Perception checks to potentially notice unusual stonework, such as traps and hidden doors located in stone walls or floors. They receive a check to notice such features whenever they pass within 10 feet of them, whether or not they are actively looking.", "+2 racial bonus on Perception skill checks" };
				this.nativeLanguages = new String[] { "Common","Dwarven" };
				this.languageAbility = new String[] { "Giant", "Gnome", "Goblin", "Orc", "Terran","Undercommon","Draconic" };
			}
}	
	
