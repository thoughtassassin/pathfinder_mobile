package com.pathfinder.unused;

public class ProClass {
	
	protected String[] alignment;
	protected String[][] advancement;
	protected int hitDie;
	protected String[] skills;
	protected int skillRanks;
	
	public ProClass()
	{
		
		this.advancement= new String[][] { 	//slow		medium		fast		feats 	ability level
											//											score
											{"",		"",			"",			"1",	""}, 	//1
											{"3000",	"2000", 	"1300", 	"", 	""}, 	//2
											{"7500",	"5000",		"3300",		"2",	""}, 	//3
											{"14000",	"9000",		"6000",		"",		"1"},	 //4
											{"23000",	"15000",	"10000",	"3",	""}, 	//5
											{"35000",	"23000",	"25000",	"",		""}, 	//6
											{"53000",	"35000",	"23000",	"4",	""}, 	//7
											{"77000",	"51000",	"34000",	"",		"2"}, 	//8
											{"115000",	"75000",	"50000",	"5",	""},	//9
											{"160000",	"105000",	"71000",	"",		""},	//10
											{"235000",	"155000",	"105000",	"6",	""},	//11
											{"330000",	"220000",	"145000",	"",		"3"},	//12
											{"475000",	"315000",	"210000",	"7",	""},	//13
											{"665000",	"445000",	"295000",	"",		""},	//14
											{"955000",	"635000",	"425000",	"8",	""},	//15
											{"1350000",	"890000",	"600000",	"",		"4"},	//15
											{"1900000",	"1300000",	"850000",	"9",	""},	//16
											{"2700000",	"1800000",	"1200000",	"",		""},	//17
											{"3850000",	"2550000",	"1700000",	"10",	""},	//18
											{"5350000",	"3600000",	"2400000",	"",		"5"}	//19
										};
		
	}
		
	protected String[] getAlignment()
	{
		return alignment;
	}
	
	protected String[][] getAdvancement()
	{
		return advancement;
	}

	protected int getHitDie()
	{
		return hitDie;
	}

	protected String[] getSkills()
	{
		return skills;
	}

	protected String[] getSkillRanks()
	{
		return alignment;
	}


}
