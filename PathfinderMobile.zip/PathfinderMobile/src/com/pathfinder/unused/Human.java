package com.pathfinder.unused;

public class Human extends Race {
	
	public Human()
	{
		super();
		this.size ="medium";
		this.abilityBonus = new String[] { "+2 User's Choice" };
		this.sizeBonus = new String[] { "Base Speed 30 ft.", "no bonuses, no penalties" };
		this.racialBonus = new String[] { "Select one extra feat at 1st level", "User gains an additional skill rank at first level and one additional rank whenever they gain a level" };
		this.nativeLanguages = new String[] { "Common" };
		this.languageAbility = new String[] { "Giant", "Gnome", "Goblin", "Orc", "Terran","Undercommon","Celestial","Draconic", "Gnoll", "Sylvan", "Dwarven", "Elven", "Abyssal" };
	}
	
}
