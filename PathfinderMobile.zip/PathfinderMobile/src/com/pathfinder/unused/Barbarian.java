package com.pathfinder.unused;

public class Barbarian extends ProClass {
	
	public Barbarian()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil", "Neutral Good" };
		this.hitDie = 12;
		this.skills= new String[] {"Acrobatics","Climb","Craft","Handle Animal","Intimidate","Knowledge-Nature","Perception","Ride","Survival","Swim"};
		this.skillRanks = 4;
	}

}
