package com.pathfinder.unused;

public class Paladin extends ProClass {
	
	public Paladin()
	{
		super();
		this.alignment = new String[] {"Lawful Good" };
		this.hitDie = 10;
		this.skills= new String[] {"Craft","Diplomacy","Handle Animal","Heal",
									"Knowledge-Nobility","Knowledge-Religion",
									"Profession","Ride","Sense Motive","Spellcraft"};
		this.skillRanks =2;
	}

}