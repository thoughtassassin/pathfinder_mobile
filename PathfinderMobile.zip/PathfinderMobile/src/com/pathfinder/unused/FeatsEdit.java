package com.pathfinder.unused;

import com.pathfinder.mobile.R;
import com.pathfinder.mobile.R.id;
import com.pathfinder.mobile.R.layout;
import com.pathfinder.mobile.R.string;
import com.pathfinder.mobile.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FeatsEdit extends Activity {
	
	private FeatsTable feat = new FeatsTable(this);
	private String id;
	private String c_id;
	private EditText feat_edit;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feats_edit);
        setTitle(R.string.edit_feats);
        
        //get the id from previous screen
        id = getIntent().getExtras().get("id").toString();
        c_id = getIntent().getExtras().get("c_id").toString();
        
        feat.open();
    
       //get the id from previous screen
       final String id = getIntent().getExtras().get("id").toString();
       String[] featToEdit = feat.getSingleFeat(id);
        
	    feat_edit = (EditText) findViewById(R.id.feat_edit);
	    feat_edit.setText(featToEdit[1]);
	    
	    Button saveCharacter = (Button) findViewById(R.id.save_button);
	    
	    // view world click event
	    saveCharacter.setOnClickListener(new View.OnClickListener() {
	    	
	    	
	        @Override
	        public void onClick(View view) {
	        	
	        	//adds a blank new feat and inserts the name New Character to be modified
	        	feat.updateFeats(id, feat_edit.getText().toString());
	        	Toast.makeText(getApplicationContext(), "Information Updated", Toast.LENGTH_SHORT).show();
	        	
	            // Launching Bio Screen
	            Intent i = new Intent(getApplicationContext(), FeatsActivity.class);
	            i.putExtra( "c_id", c_id );
	                startActivity(i);
	                finish();
	 
	            }
	        });
    };
    
    protected void onResume() {
    	super.onResume();
        feat.open();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        feat.close();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        feat.close();
    }

}
