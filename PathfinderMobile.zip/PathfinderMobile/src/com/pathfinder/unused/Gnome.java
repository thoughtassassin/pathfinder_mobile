package com.pathfinder.unused;

public class Gnome extends Race{
	
	public Gnome(){
		super();
		this.size ="small";
		this.abilityBonus = new String[] { "+2 Constituion", "+2 Charisma", "-2 Strength" };
		this.sizeBonus = new String[] { "+1 to AC", "+1 to attack rolls", "-1 penalty to combat maneuver", "+4 size bonus to stealth checks", "Base speed 20ft" };
		this.racialBonus = new String[] { "Can see twice as far as humans in conditions of dim light", "+4 dodge bonus to AC against monsters of the giant type", "+1 to the DC of any saving throws against illusion spells cast", "+1 bonus on attack rolls against humanoid creatures of the reptilian and goblinoid subtypes", "+2 racial saving throw bonus against illusion spells or effects", "+2 racial bonus on Perception skill checks", "+2 racial bonus on a Craft or Profession skill of their choice", "Treat any weapon with the word �gnome� in its name as a martial weapon"};
		this.nativeLanguages = new String[] { "Common", "Gnome", "Sylvan" };
		this.languageAbility = new String[] { "Giant", "Goblin", "Orc","Draconic", "Dwarven", "Elven" };
	}

}
