package com.pathfinder.unused;

import com.pathfinder.mobile.GearActivity;
import com.pathfinder.mobile.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class FeatsActivity extends Activity {
	
	public Cursor cursor;
	private ListView featsList;
	private FeatsTable newFeats;
	final Context context = this;
	private String c_id;
	private String clickID;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feats_page);
        setTitle(R.string.feats_screen);
        
       //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
        
        newFeats = new FeatsTable(this); 
        newFeats.open();
        
        Button btnNewFeat = (Button) findViewById(R.id.add_feat_button);
        Button btnNextScreen = (Button) findViewById(R.id.next_button);
        
        if (newFeats.characterRecordExists(c_id))
        {
        	showData();
        }
        
        // view world click event
        btnNewFeat.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
            	//adds a blank new character and inserts the name New Character to be modified
                long insertID = newFeats.addFeats(c_id, "New Feat");
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), FeatsEdit.class);
                i.putExtra( "c_id", c_id );
                i.putExtra( "id", insertID );
                startActivity(i);
                finish();
 
            }
        });
        
        // view world click event
        btnNextScreen.setOnClickListener(new View.OnClickListener() {
        
            @Override
            public void onClick(View view) {
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), GearActivity.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
 
            }
        });
    }
    
    public void showData() {
    	
    	 featsList = (ListView) findViewById(R.id.feats_list);
         Cursor cursor = newFeats.getCursor(c_id);
         
         String[] from = { FeatsTable.KEY_ID, FeatsTable.KEY_FEAT };
         int[] to = { R.id.characterID, R.id.itemFeats };
         SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.featsrow , cursor, from, to);
         featsList.setAdapter(adapter); 
         
         featsList.setOnItemClickListener(new OnItemClickListener() {
         // @Override
         public void onItemClick(AdapterView<?> a, View v, int position, long id) {
        	 
        	 clickID = String.valueOf(id);
        	         	 
        	 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
     				context);
      
     			// set title
     			alertDialogBuilder.setTitle("Feats Manager");
      
     			// set dialog message
     			alertDialogBuilder
     				.setMessage("Would you like to Edit or Delete this feat?")
     				.setCancelable(false)
     				.setPositiveButton("Edit",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						
     						 // Launching Bio Screen
     						Intent i = new Intent(getApplicationContext(), FeatsEdit.class);
     			            i.putExtra( "id", clickID );
     			            i.putExtra( "c_id", c_id );
     			            startActivity(i);
     			            finish();
     			            
     					}
     				  })
     				.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						// if this button is clicked, just close
     						// the dialog box and do nothing
     						dialog.cancel();
     					}
     				})
     				.setNeutralButton("Delete",new DialogInterface.OnClickListener() {
         					public void onClick(DialogInterface dialog,int id) {
         					
         						newFeats.deleteFeats(clickID);
         						showData();
         						dialog.cancel();
         					}
     				});
      
     				// create alert dialog
     				AlertDialog alertDialog = alertDialogBuilder.create();
      
     				// show it
     				alertDialog.show();
            
         }
         });
    	
    }
    
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		newFeats.open();
		if (newFeats.characterRecordExists(c_id))
        {
        	showData();
        }
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        newFeats.close();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        newFeats.close();
    }


}
