package com.pathfinder.unused;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeaponsTable extends SQLiteOpenHelper {
	
	// All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "WeaponsInfo";
 
    // Size table name
    private static final String TABLE_WEAPONS = "WeaponsTable";
 
    // Size Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_C_ID = "c_id";
    private static final String KEY_WEAPON = "weapon";
    private static final String KEY_CRITICAL = "critical";
    private static final String KEY_TYPE = "type";
    private static final String KEY_RANGE = "range";
    private static final String KEY_AMMUNITION = "ammunition";
    private static final String KEY_DAMAGE = "damage";
    
    public WeaponsTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub


}

public void onCreate(SQLiteDatabase db) {
		
		String CREATE_WEAPONS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_WEAPONS + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_C_ID + " INTEGER, "
				+ KEY_WEAPON + " STRING, "
				+ KEY_CRITICAL + " INTEGER, "
				+ KEY_TYPE + " STRING, "
				+ KEY_RANGE + " INTEGER, "
				+ KEY_DAMAGE + " INTEGER, "
				+ KEY_AMMUNITION + " STRING " + ")";
        db.execSQL(CREATE_WEAPONS_TABLE);
		
	}

public SQLiteDatabase databaseName()
{
	return this.getWritableDatabase();
}


 // Upgrading database
@Override
public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    // Drop older Abilities table if existed
    db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEAPONS);

    // Create tables again
    onCreate(db);
    
}

public long addAbilities(String c_id, String weapon, String critical, String type, String range,
		String ammunition, String damage) {
	
	   SQLiteDatabase db = this.getWritableDatabase();
	   
	   ContentValues values = new ContentValues();
	   values.put(KEY_C_ID, c_id);
	   values.put(KEY_WEAPON, weapon);
	   values.put(KEY_CRITICAL, critical); 
	   values.put(KEY_TYPE, type); 
	   values.put(KEY_RANGE, range);   
	   values.put(KEY_AMMUNITION, ammunition);
	   values.put(KEY_DAMAGE, damage); 
	 
	   // Inserting Row
	   long insertID = db.insert(TABLE_WEAPONS, null, values);
	   db.close(); // Closing database connection
	   
	   return insertID;
	
}

public String[] getWeapons(String characterID) {
    
	SQLiteDatabase db = this.getReadableDatabase();
	String[] characterWeapons = new String[6];
    
    Cursor cursor = db.query(TABLE_WEAPONS, new String[] { KEY_C_ID, KEY_WEAPON, KEY_CRITICAL, KEY_TYPE,
    		KEY_RANGE,KEY_AMMUNITION,KEY_DAMAGE }, KEY_ID + "=?",
            new String[] { characterID }, null, null, null, null);
    
    if (cursor.moveToFirst())
    {
        //enter character attributes into string
        for (int i = 0; i < characterWeapons.length; i++ )
        {
        	characterWeapons[i] = cursor.getString(i);
        }
    }
    
   return characterWeapons;
            
}

public int updateWeapons(String c_id, String weapon, String critical, String type, String range,
		String ammunition, String damage) {
    
	SQLiteDatabase db = this.getWritableDatabase();
 
    ContentValues values = new ContentValues();
    values.put(KEY_WEAPON, weapon);
    values.put(KEY_CRITICAL, critical); 
    values.put(KEY_TYPE, type); 
    values.put(KEY_RANGE, range);   
    values.put(KEY_AMMUNITION, ammunition); 
    values.put(KEY_DAMAGE, damage);   
    // updating row
    return db.update(TABLE_WEAPONS, values, KEY_C_ID + " = ?",
            new String[] { c_id });
}

public boolean recordExists(String c_id)
{

  SQLiteDatabase db = this.getReadableDatabase();
  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_WEAPONS +" WHERE c_id=?", 
	        new String[] { c_id });
  boolean exists = (cursor.getCount() > 0);
  cursor.close();
  
  return exists;
	
}

}

