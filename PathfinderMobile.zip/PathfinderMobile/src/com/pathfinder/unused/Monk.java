package com.pathfinder.unused;

public class Monk extends ProClass {
	
	public Monk ()
	{
		super();
		this.alignment = new String[] { "Lawful Good", "Lawful Neutral", "Lawful Evil" };
		this.hitDie = 8;
		this.skills= new String[] {"Acrobatics","Climb","Craft","Escape Artist","Intimidate","Knowledge-History","Knowledge-Religion",
									"Perception","Perform","Sense Motive","Ride","Stealth","Swim"};
		this.skillRanks = 4;
	}

}
