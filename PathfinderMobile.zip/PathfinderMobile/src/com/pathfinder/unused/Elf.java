package com.pathfinder.unused;

public class Elf extends Race{
	public Elf(){
		super();
		this.size ="medium";
		this.abilityBonus = new String[] { "+2 Dexterity", "+2 Intelligence", "-2 Constitution" };
		this.sizeBonus = new String[] { "Base Speed 30 ft.", "no bonuses, no penalties" };
		this.racialBonus = new String[] { "Can see twice as far as humans in conditions of dim light", "Immune to magic sleep effects", "+2 racial saving throw bonus against enchantment spells and effects", "+2 racial bonus on caster level checks made to overcome spell resistance", "+2 racial bonus on Spellcraft skill checks made to identify the properties of magic items", "+2 racial bonus on Perception skill checks" };
		this.nativeLanguages = new String[] { "Common" };
		this.languageAbility = new String[] { "Gnome", "Goblin", "Orc","Celestial","Draconic", "Gnoll", "Sylvan" };
	}
}
