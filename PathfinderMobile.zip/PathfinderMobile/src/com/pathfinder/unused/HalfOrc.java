package com.pathfinder.unused;

public class HalfOrc extends Race {

	public HalfOrc()
	{
		super();
		this.size = "medium";
		this. abilityBonus = new String[] {"+2 User�s choice"};
		this. sizeBonus= new String[] {"Base Speed 30 ft.","no bonuses, no penalties"};
		this. racialBonus= new String[] {"Can see in the dark up to 60 feet","+2 racial bonus on Intimidate skill checks","Included in all Orc racial effects","Once per day, when a half-orc is brought below 0 hit points but not killed, he can fight on for one more round as if disabled. At the end of his next turn, unless brought to above 0 hit points, he immediately falls unconscious and begins dying.",};
		this. nativeLanguages= new String[] {"Common","Orc"};
		this. languageAbility= new String[] {"Giant","Goblin","Draconic","Gnoll","Abyssal"};
	}
}
