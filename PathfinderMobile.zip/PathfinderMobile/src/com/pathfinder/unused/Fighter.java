package com.pathfinder.unused;

public class Fighter extends ProClass {
	
	public Fighter()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil","Neutral", "Neutral Good", "Lawful Evil", "Lawful Neutral", "Lawful Good" };
		this.hitDie = 10;
		this.skills= new String[] {"Climb","Craft","Diplomacy","Handle Animal","Intimidate","Knowledge-Dungeoneering","Knowledge-Engineering",
									"Profession","Ride","Survival","Swim","Stealth"};
		this.skillRanks =2;
	}

}