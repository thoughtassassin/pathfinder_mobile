package com.pathfinder.unused;

public class Rogue extends ProClass {
	
	public Rogue()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil","Neutral", "Neutral Good", "Lawful Evil", "Lawful Neutral", "Lawful Good" };
		this.hitDie = 8;
		this.skills= new String[] {"Acrobatics","Appraise","Bluff","Climb","Craft","Diplomacy","Device","Disguise",
									"Escape Artist","Intimidate","Knowledge-Dungeoneering","Knowledge-Local","Linguistics","Perception",
									"Perform","Profession","Motive","Sleight of Hand","Swim","Use Magic Device"};
		this.skillRanks = 8;
	}

}
