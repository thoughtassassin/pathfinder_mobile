package com.prototypetwo.krause;

public class Sorcerer extends ProClass {
	
	public Sorcerer()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil","Neutral", "Neutral Good", "Lawful Evil", "Lawful Neutral", "Lawful Good" };
		this.hitDie = 6;
		this.skills= new String[] {"Appraise","Bluff","Craft","Fly","Intimidate",
									"Knowledge-Arcana","Profession","Spellcraft","Use Magic Device"};
		this.skillRanks =2;
	}

}