package com.prototypetwo.krause;

public class Race {

	protected String size;
	protected String[] abilityBonus;
	protected String[] sizeBonus;
	protected String[] racialBonus;
	protected String[] nativeLanguages;
	protected String[] languageAbility;
	
	public Race ()
	{
		
	}
	
	//returns Size
	protected String getSize()
	{
		return size;
	}
	
	//returns Size
	protected String[] getAbilityBonus()
	{
		return abilityBonus;
	}
	
	//returns Size
	protected String[] getSizeBonus()
	{
		return sizeBonus;
	}//sets Size
	
	//returns Size
	protected String[] getRacialBonus()
	{
		return racialBonus;
	}
	
	//returns Size
	protected String[] getNativeLanguages()
	{
		return nativeLanguages;
	}
	
	//returns Size
	protected String[] getLanguageAbility()
	{
		return languageAbility;
	}
	
	
}
