package com.prototypetwo.krause;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class SavingThrowTable extends SQLiteOpenHelper {
	
	 // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "SavingThrowInfo";
 
    // Size table name
    private static final String TABLE_SAVINGTHROW = "SavingThrowTable";
 
    // Size Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_C_ID = "c_id";
    private static final String KEY_BASE_SAVE = "base_save";
    private static final String KEY_ABILITY_MODIFIER = "ability_modifier";
    private static final String KEY_MAGIC_MODIFIER = "magic_modifier";
    private static final String KEY_MISC_MODIFIER = "misc_modifier";
    private static final String KEY_TEMP_MODIFIER= "temp_modifier";
    private static final String KEY_SAVING_THROW_TYPE= "saving_throw_type";
    
    public SavingThrowTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
}
    
public void onCreate(SQLiteDatabase db) {
		
		String CREATE_SAVING_THROW_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_SAVINGTHROW + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_C_ID + " INTEGER, "
				+ KEY_BASE_SAVE + " INTEGER, "
				+ KEY_ABILITY_MODIFIER + " INTEGER, "
				+ KEY_MAGIC_MODIFIER + " INTEGER, "
				+ KEY_MISC_MODIFIER + " INTEGER, "
				+ KEY_ABILITY_MODIFIER + " INTEGER, "
				+ KEY_TEMP_MODIFIER + " INTEGER, "
				+ KEY_SAVING_THROW_TYPE + " INTEGER " + ")";
        db.execSQL(CREATE_SAVING_THROW_TABLE);
		
	}

public SQLiteDatabase databaseName()
{
	return this.getWritableDatabase();
}


 // Upgrading database
@Override
public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    // Drop older Abilities table if existed
    db.execSQL("DROP TABLE IF EXISTS " + TABLE_SAVINGTHROW);

    // Create tables again
    onCreate(db);
    
}

public long addSavingThrow(String c_id, String base_save, String ability_modifier, String magic_modifier, String misc_modifier,
		String temp_modifier, String saving_throw_type ) {
	
	   SQLiteDatabase db = this.getWritableDatabase();
	   
	   ContentValues values = new ContentValues();
	   values.put(KEY_C_ID, c_id);
	   values.put(KEY_BASE_SAVE, base_save);
	   values.put(KEY_ABILITY_MODIFIER,ability_modifier); 
	   values.put(KEY_MAGIC_MODIFIER, magic_modifier); 
	   values.put(KEY_MISC_MODIFIER, misc_modifier);   
	   values.put(KEY_TEMP_MODIFIER,temp_modifier);
	   values.put(KEY_SAVING_THROW_TYPE, saving_throw_type);  
	 
	   // Inserting Row
	   long insertID = db.insert(TABLE_SAVINGTHROW, null, values);
	   db.close(); // Closing database connection
	   
	   return insertID;
	
}

public String[] getSavingThrow(String characterID) {
    
	SQLiteDatabase db = this.getReadableDatabase();
	String[] characterSavingThrow = new String[6];
    
    Cursor cursor = db.query(TABLE_SAVINGTHROW, new String[] { KEY_C_ID, KEY_BASE_SAVE, KEY_ABILITY_MODIFIER, KEY_MAGIC_MODIFIER,
    		KEY_MISC_MODIFIER, KEY_TEMP_MODIFIER, KEY_SAVING_THROW_TYPE }, KEY_ID + "=?",
            new String[] { characterID }, null, null, null, null);
    
    if (cursor.moveToFirst())
    {
        //enter character attributes into string
        for (int i = 0; i < characterSavingThrow.length; i++ )
        {
        	characterSavingThrow[i] = cursor.getString(i);
        }
    }
    
   return characterSavingThrow;
            
}

public boolean recordExists(String c_id)
{

  SQLiteDatabase db = this.getReadableDatabase();
  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_SAVINGTHROW +" WHERE c_id=?", 
	        new String[] { c_id });
  boolean exists = (cursor.getCount() > 0);
  cursor.close();
  
  return exists;
	
}

}


