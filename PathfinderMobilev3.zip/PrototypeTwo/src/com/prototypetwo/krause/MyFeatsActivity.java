package com.prototypetwo.krause;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MyFeatsActivity extends Activity {
	
	public Cursor cursor;
	private ListView featsList;
	private FeatsTable2 newFeats;
	final Context context = this;
	private String c_id;
	private String clickID;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myfeats_page);
        setTitle(R.string.my_feats);
        
        //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
        
        newFeats = new FeatsTable2(this); 
        newFeats.open();
        
        Button btnBack = (Button) findViewById(R.id.back_button);
        
        showData();
        
        // view world click event
        btnBack.setOnClickListener(new View.OnClickListener() {
        	
        	
            @Override
            public void onClick(View view) {
            	
                // Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                i.putExtra( "c_id", c_id );
                startActivity(i);
                finish();
 
            }
        });
        
    }
    
    public void showData() {
    	
    	 featsList = (ListView) findViewById(R.id.feats_list);
         Cursor cursor = newFeats.myFeatsCursor(c_id);
         
         String[] from = { FeatsTable2.KEY_ID, FeatsTable2.KEY_NAME, FeatsTable2.KEY_DESCRIPTION };
         int[] to = { R.id.featID, R.id.featName, R.id.featDescription };
         SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.featsrow2 , cursor, from, to);
         featsList.setAdapter(adapter); 
         
         featsList.setOnItemClickListener(new OnItemClickListener() {
         // @Override
         public void onItemClick(AdapterView<?> a, View v, int position, long id) {
        	 
        	 clickID = String.valueOf(id);
        	         	 
        	 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
     				context);
      
     			// set title
     			alertDialogBuilder.setTitle("Feats Manager");
      
     			// set dialog message
     			alertDialogBuilder
     				.setMessage("Would you like to Delete this feat?")
     				.setCancelable(false)
     				.setPositiveButton("Delete",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						
     						 // Launching Bio Screen
     						newFeats.deleteFeats(clickID);
     						showData();
     			            
     					}
     				  })
     				.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
     					public void onClick(DialogInterface dialog,int id) {
     						// if this button is clicked, just close
     						// the dialog box and do nothing
     						dialog.cancel();
     					}
     				});

      
     				// create alert dialog
     				AlertDialog alertDialog = alertDialogBuilder.create();
      
     				// show it
     				alertDialog.show();
            
         }
         });
    	
    }
    
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		newFeats.open();
		if (newFeats.characterRecordExists(c_id))
        {
        	showData();
        }
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        newFeats.close();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        newFeats.close();
    }


}
