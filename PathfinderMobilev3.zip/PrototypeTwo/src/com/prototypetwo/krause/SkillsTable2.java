package com.prototypetwo.krause;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Modificiation of Google's simple notes db tutorial. Defines the basic CRUD operations
 * for the notepad example, and gives the ability to list all notes as well as
 * retrieve or modify a specific note.
 * 
 * This has been improved from the first version of this tutorial through the
 * addition of better error handling and also using returning a Cursor instead
 * of using a collection of inner classes (which is less scalable and not
 * recommended).
 */
public class SkillsTable2 {
	
	// Database Version
    private static final int DATABASE_VERSION = 1;
	
	private static final String DATABASE_NAME = "SkillsInfo";
	 
    // Size table name
    private static final String TABLE_SKILLS = "SkillsTable";

	// Size Table Columns names
    public static final String KEY_ID = "_id";
    public static final String KEY_C_ID = "c_id";
    public static final String KEY_TOTAL_BONUS = "total_bonus";
    public static final String KEY_SKILL_NAME = "skillname";
    public static final String KEY_ABILITY_MOD = "ability_mod";
    public static final String KEY_ABILITY_MOD_LABEL = "ability_mod_label";
    public static final String KEY_RANK = "rank";
    public static final String KEY_MISC_MODIFIER = "miscmodifier";

    private static final String TAG = "NotesDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    /**
     * Database creation sql statement
     */
    private static final String DATABASE_CREATE = "CREATE TABLE IF NOT EXISTS " + TABLE_SKILLS + " ("
			+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
			+ KEY_C_ID + " INTEGER, "
			+ KEY_SKILL_NAME + " STRING, "
			+ KEY_TOTAL_BONUS + " INTEGER, "
			+ KEY_ABILITY_MOD + " INTEGER, "
			+ KEY_ABILITY_MOD_LABEL + " STRING, "
			+ KEY_RANK + " INTEGER, "
			+ KEY_MISC_MODIFIER + " INTEGER " + ")";

    private final Context mCtx;

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS notes");
            onCreate(db);
        }
    }

    /**
     * Constructor - takes the context to allow the database to be
     * opened/created
     * 
     * @param ctx the Context within which to work
     */
    public SkillsTable2(Context ctx) {
        this.mCtx = ctx;
    }

    /**
     * Open the notes database. If it cannot be opened, try to create a new
     * instance of the database. If it cannot be created, throw an exception to
     * signal the failure
     * 
     * @return this (self reference, allowing this to be chained in an
     *         initialization call)
     * @throws SQLException if the database could be neither opened or created
     */
    public SkillsTable2 open() throws SQLException {
    	
    	if ( mDb == null || !(mDb.isOpen()) )  
    	{
	        mDbHelper = new DatabaseHelper(mCtx);
	        mDb = mDbHelper.getWritableDatabase();
    	}
    	
    	return this;
  
    }

    public void close() {
        mDbHelper.close();
    }


    /**
     * Return a Cursor over the list of all notes in the database
     * 
     * @return Cursor over all notes
     */
    public Cursor fetchAllSkills(String c_id) {

        return mDb.query(TABLE_SKILLS, new String[] {KEY_ID, KEY_C_ID, KEY_SKILL_NAME, KEY_TOTAL_BONUS,
                KEY_ABILITY_MOD, KEY_ABILITY_MOD_LABEL, KEY_RANK, KEY_MISC_MODIFIER}, KEY_C_ID + "=" + c_id, null, null, null, null);
    }

    /**
     * Return a Cursor positioned at the note that matches the given rowId
     * 
     * @param rowId id of note to retrieve
     * @return Cursor positioned to matching note, if found
     * @throws SQLException if note could not be found/retrieved
     */
    public Cursor fetchSkills(long rowId) throws SQLException {
    	    	
        Cursor mCursor =

            mDb.query(TABLE_SKILLS, new String[] { KEY_ID, KEY_C_ID, KEY_SKILL_NAME, KEY_TOTAL_BONUS,
                    KEY_ABILITY_MOD, KEY_ABILITY_MOD_LABEL, KEY_RANK, KEY_MISC_MODIFIER }, KEY_ID + "=" + rowId, null, null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    /**
     * Update the note using the details provided. The note to be updated is
     * specified using the rowId, and it is altered to use the title and body
     * values passed in
     * 
     * @param rowId id of note to update
     * @param title value to set note title to
     * @param body value to set note body to
     * @return true if the note was successfully updated, false otherwise
     */
    public boolean updateSkill(long rowId, String totalBonus, 
    		String ability_mod, String rank, String miscmodifier) {
        ContentValues args = new ContentValues();
        args.put(KEY_TOTAL_BONUS, totalBonus);
        args.put(KEY_ABILITY_MOD, ability_mod);
        args.put(KEY_RANK, rank);
        args.put(KEY_MISC_MODIFIER, miscmodifier);

        return mDb.update(TABLE_SKILLS, args, KEY_ID + "=" + rowId, null) > 0;
    }
    
    public long addSkills(String c_id, String skillname, String totalBonus, String ability_mod,  
    		String ability_mod_label, String rank, String miscmodifier)
    {    	   
    	   ContentValues values = new ContentValues();
    	   values.put(KEY_C_ID, c_id);
    	   values.put(KEY_SKILL_NAME, skillname);
    	   values.put(KEY_TOTAL_BONUS, totalBonus);
    	   values.put(KEY_ABILITY_MOD, ability_mod);
    	   values.put(KEY_ABILITY_MOD_LABEL, ability_mod_label);
    	   values.put(KEY_RANK, rank); 
    	   values.put(KEY_MISC_MODIFIER, miscmodifier); 
    	 
    	   // Inserting Row
    	   long insertID = mDb.insert(TABLE_SKILLS, null, values);
    	   
    	   return insertID;
    	
    }
    
  //delete Skills
    public void deleteSkills(String c_id) {
    	if (recordExists(c_id))
    	{
    		mDb.delete(TABLE_SKILLS, KEY_C_ID + " = ?",
                    new String[] { c_id });
    	}
    }

    public boolean recordExists(String c_id)
    {
      Cursor cursor = mDb.rawQuery("SELECT 1 FROM " + TABLE_SKILLS +" WHERE c_id=?", 
    	        new String[] { c_id });
      boolean exists = (cursor.getCount() > 0);
      cursor.close();
      
      return exists;
    	
    }
}

