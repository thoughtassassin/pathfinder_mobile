package com.prototypetwo.krause;

public class Ranger extends ProClass {
	
	public Ranger()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil","Neutral", "Neutral Good", "Lawful Evil", "Lawful Neutral", "Lawful Good" };
		this.hitDie = 10;
		this.skills= new String[] {"Climb","Craft","Handle Animal","Heal","Intimidate","Knowledge-Dungeoneering",
									"Knowledge-Geography","Knowledge-Nature","Perception","Profession","Ride","Spellcraft",
									"Stealth","Survival","Swim"};
		this.skillRanks = 6;
	}

}
