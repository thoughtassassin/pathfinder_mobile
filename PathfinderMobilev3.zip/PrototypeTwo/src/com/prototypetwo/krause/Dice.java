package com.prototypetwo.krause;

/**
 * This class creates all the dice rolls for the game.
 * Simply call the method that matches the die that you
 * want to use. The only argument to each of the methods
 * is the number of times that you want to roll
 * the die. For example, if you want to roll the six
 * sided die five times the method will return the
 * result of the die being rolled five times.
 */

import java.util.Arrays;
import java.util.Random;

public class Dice {
	
	static Random r = new Random();
	
	public static int classicAbilitiesRoll()
	{
		
		/* This is the method for generating abilities.
		 * A six-sided die is rolled six times.
		 * The lowest number is discarded.
		 */
		
		int[] rollsArray = new int [4];
		
		int d6 = 0; //initialize integer to be returned
		
		for ( int i=0; i < 4; i++ ) //number of times die rolled
		{
			
			rollsArray[i] = 1 + r.nextInt( (6-1) + 1); //add to the roll total
			
		}
		
		Arrays.sort(rollsArray);
		
		for ( int i=1; i < 4; i++ ) //number of times die rolled
		{
			
			d6 += rollsArray[i];
			System.out.print(rollsArray[i] + " ");
			
		}		
		
		return d6;
	}
	
	public static int fourSidedDie (int numOfTimes)
	{
		int d4 = 0; //initialize integer to be returned
		
		for ( int i=0; i<numOfTimes; i++ ) //number of times die rolled
		{
			d4 += 1 + r.nextInt( (4-1) + 1); //add to the roll total
		}
		
		return d4;
	}
	
	public static int sixSidedDie (int numOfTimes)
	{
		int d6 = 0; //initialize integer to be returned
		
		for ( int i=0; i<numOfTimes; i++ ) //number of times die rolled
		{
			d6 += 1 + r.nextInt( (6-1) + 1); //add to the roll total
		}
		
		return d6;
	}
	
	public static int eightSidedDie (int numOfTimes)
	{
		int d8 = 0; //initialize integer to be returned
		
		for ( int i=0; i<numOfTimes; i++ ) //number of times die rolled
		{
			d8 += 1 + r.nextInt( (8-1) + 1); //add to the roll total
		}
		
		return d8;
	}
	
	public static int tenSidedDie (int numOfTimes)
	{
		int d10 = 0; //initialize integer to be returned
		
		for ( int i=0; i<numOfTimes; i++ ) //number of times die rolled
		{
			d10 += 1 + r.nextInt( (10-1) + 1); //add to the roll total
		}
		
		return d10;
	}
	
	public static int twelveSidedDie (int numOfTimes)
	{
		int d12 = 0; //initialize integer to be returned
		
		for ( int i=0; i<numOfTimes; i++ ) //number of times die rolled
		{
			d12 += 1 + r.nextInt( (12-1) + 1); //add to the roll total
		}
		
		return d12;
	}
	
	public static int twentySidedDie (int numOfTimes)
	{
		int d20 = 0; //initialize integer to be returned
		
		for ( int i=0; i<numOfTimes; i++ ) //number of times die rolled
		{
			d20 += 1 + r.nextInt( (20-1) + 1); //add to the roll total
		}
		
		return d20;
	}
	
	public static void main (String[] args)
	{
		classicAbilitiesRoll ();
	}
	


}
