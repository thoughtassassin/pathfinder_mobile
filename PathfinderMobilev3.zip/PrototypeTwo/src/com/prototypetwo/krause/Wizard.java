package com.prototypetwo.krause;

public class Wizard extends ProClass {
	
	public Wizard()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil","Neutral", "Neutral Good", "Lawful Evil", "Lawful Neutral", "Lawful Good" };
		this.hitDie = 6;
		this.skills= new String[] {"Appraise","Craft","Fly","Knowledge-Arcana","Knowledge-Dungeoneering","Knowledge-Engineering",
									"Knowledge-Geography","Knowledge-History","Knowledge-Local","Knowledge-Nature",
									"Knowledge-Nobility","Knowledge-Planes","Knowledge-Religion","Linguistics","Profession","Spellcraft"};
		this.skillRanks =2;
	}

}