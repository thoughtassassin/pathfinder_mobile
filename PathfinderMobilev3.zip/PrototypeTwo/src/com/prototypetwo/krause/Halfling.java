package com.prototypetwo.krause;

public class Halfling extends Race{
	public Halfling(){
		super();
		this.size ="small";
		this.abilityBonus = new String[] { "+2 Dexterity", "+2 Charisma", "-2 Strength" };
		this.sizeBonus = new String[] { "+1 to AC", "+1 to attack rolls", "-1 penalty to combat maneuver", "+4 size bonus to stealth checks", "Base speed 20ft" };
		this.racialBonus = new String[] { "+2 racial bonus on Perception skill checks", "+2 racial bonus on all saving throws against fear. This bonus stacks with the bonus granted by halfling luck.", "+1 racial bonus on all saving throws (Halfling Luck)", "+2 racial bonus on Acrobatics and Climb skill checks"};
		this.nativeLanguages = new String[] { "Common", "Halfling" };
		this.languageAbility = new String[] { "Gnome", "Goblin", "Dwarven", "Elven" };
	}
	
}
