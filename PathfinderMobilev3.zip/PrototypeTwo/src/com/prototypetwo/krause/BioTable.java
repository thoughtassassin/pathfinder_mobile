package com.prototypetwo.krause;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

public class BioTable extends SQLiteOpenHelper {
	
    // All Static variables
    // Database Version
    public static final int DATABASE_VERSION = 1;
 
    // Database Name
    public static final String DATABASE_NAME = "BioInfo";
 
    // Bio table name
    public static final String TABLE_BIO = "BioTable";
 
    //Bio Table Columns names
    public static final String KEY_ID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_RACE = "race";
    public static final String KEY_CLASS = "class";
    public static final String KEY_ALIGNMENT = "alignment";
    public static final String KEY_LEVEL = "level";
    public static final String KEY_DEITY = "deity";
    public static final String KEY_DESCRIPTION = "description";
    public static final String KEY_SIZE = "medium";
    
    //database for our class
    private SQLiteDatabase db;
    
	public BioTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		String CREATE_BIO_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_BIO + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_NAME + " TEXT,"
				+ KEY_RACE + " TEXT, "
				+ KEY_CLASS + " TEXT, "
				+ KEY_ALIGNMENT + " TEXT, "
				+ KEY_LEVEL + " TEXT, "
				+ KEY_DEITY + " TEXT, "
				+ KEY_DESCRIPTION + " TEXT, "
                + KEY_SIZE + " TEXT " + ")";
        db.execSQL(CREATE_BIO_TABLE);
		
	}

	 // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BIO);
 
        // Create tables again
        onCreate(db);
    }
    
    //open db
  	public SQLiteDatabase open() throws SQLException
  	{
  		return db = this.getWritableDatabase();
  	}
  	
  	//close db
  	 public void close()
  	 {
  		 db.close();
  		 
  	 }
    
    // Adding bio for character
    public long addBio(String name, String race, String chClass, String alignment,
    		String level, String deity, String description, String size) {
    	    	   
    	   ContentValues values = new ContentValues();
    	   values.put(KEY_NAME, name); // Character Name
    	   values.put(KEY_RACE, race); // Character Race
    	   values.put(KEY_CLASS, chClass); // Character Class
    	   values.put(KEY_ALIGNMENT, alignment); // Character Alignment
    	   values.put(KEY_LEVEL, level); // Character Level   
    	   values.put(KEY_DEITY, deity); // Character Deity
    	   values.put(KEY_DESCRIPTION, description); // Character Description
    	   values.put(KEY_SIZE, size); // Character Size     
    	 
    	   // Inserting Row
    	   long insertID = db.insert(TABLE_BIO, null, values);
    	   
    	   return insertID;
    	
    }
     
    // Getting Character Bio Attributes
    public String[] getBio(String characterID) {
        
    	String[] characterAttributes = new String[8]; //string to get all character attributes
        
        Cursor cursor = db.query(TABLE_BIO, new String[] { KEY_NAME, KEY_RACE, KEY_CLASS, KEY_ALIGNMENT,
        		KEY_LEVEL, KEY_DEITY, KEY_DESCRIPTION, KEY_SIZE }, KEY_ID + "=?",
                new String[] { characterID }, null, null, null, null);
        
        if (cursor.moveToFirst())
        {
	        //enter character attributes into string
	        for (int i = 0; i < characterAttributes.length; i++ )
	        {
	        	characterAttributes[i] = cursor.getString(i);
	        }
        }
 	   
       return characterAttributes;
                
    }
	
    public int updateBio( String id, String name, String race, String chClass, String alignment,
    		String level, String deity, String description, String size ) {
            
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_RACE, race);
        values.put(KEY_CLASS, chClass);
    	values.put(KEY_ALIGNMENT, alignment);
        values.put(KEY_LEVEL, level);
        values.put(KEY_DEITY, deity);
        values.put(KEY_DESCRIPTION, description);
        values.put(KEY_SIZE, size);
     
        // updating row
        return db.update(TABLE_BIO, values, KEY_ID + " = ?",
                new String[] { id });
    }
    
    public int updateBio( String id, String name, String description ) {
            
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_DESCRIPTION, description);
     
        // updating row
        return db.update(TABLE_BIO, values, KEY_ID + " = ?",
                new String[] { id });
    }
    
   //update Bio for Abilities Screen
    public int updateAbilitiesBio( String id, String race, String chClass ) {
        
        ContentValues values = new ContentValues();
        values.put(KEY_RACE, race);
        values.put(KEY_CLASS, chClass);
     
        // updating row
        return db.update(TABLE_BIO, values, KEY_ID + " = ?",
                new String[] { id });
    }
    
    //update Bio for Other Screen
    public int updateOtherBio( String id, String level, String alignment ) {
        
        ContentValues values = new ContentValues();
        values.put(KEY_LEVEL, level);
        values.put(KEY_ALIGNMENT, alignment);
     
        // updating row
        return db.update(TABLE_BIO, values, KEY_ID + " = ?",
                new String[] { id });
    }
    
    //delete Bio
    public void deleteBio(String id) {
        
    	if (recordExists(id))
    	{
	        db.delete(TABLE_BIO, KEY_ID + " = ?",
	                new String[] { id });
    	}
    }
    
    //Cursor to retrive existing characters
    public Cursor getCursor()
    {
    	
    	SQLiteDatabase db = this.getReadableDatabase();
    	SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
    	
    	queryBuilder.setTables(TABLE_BIO);
    	
    	String[] asColumnsToReturn = new String[] { KEY_ID, KEY_NAME };
    	
    	Cursor mCursor = queryBuilder.query(db, asColumnsToReturn, null, null, null, null, "name ASC");
    	
    	return mCursor;
    }
    
    public boolean recordExists(String id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_BIO +" WHERE _id=?", 
		        new String[] { id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}
    
}
