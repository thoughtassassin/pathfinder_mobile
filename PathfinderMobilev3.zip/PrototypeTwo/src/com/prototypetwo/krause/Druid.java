package com.prototypetwo.krause;

public class Druid extends ProClass {
	
	public Druid ()
	{
		super();
		this.alignment = new String[] { "Chaotic Neutral", "Neutral Evil","Neutral", "Neutral Good", "Lawful Neutral" };
		this.hitDie = 8;
		this.skills= new String[] {"Climb","Craft","Fly","Handle Animal","Heal","Knowledge-Geography",
									"Knowledge-Nature","Perception","Profession","Ride",
									"Spellcraft","Survival","Swim"};
		this.skillRanks = 4;
	}

}
