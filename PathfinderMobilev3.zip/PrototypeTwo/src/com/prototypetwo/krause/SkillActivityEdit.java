package com.prototypetwo.krause;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SkillActivityEdit extends Activity {
	
	private TextView totalBonusText;
    private TextView abilityModifierText;
    private EditText ranksModifierText;
    private EditText miscModifierText;
    private Button btnSaveButton;
    private Long mRowId;
    private SkillsTable2 mDbHelper;
    private String title;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.skill_edit);
        
        mDbHelper = new SkillsTable2(this);
        mDbHelper.open();
        
        totalBonusText = (TextView) findViewById(R.id.total_bonus_textfield);
        abilityModifierText = (TextView) findViewById(R.id.ability_modifier_textfield);
        ranksModifierText = (EditText) findViewById(R.id.ranks_modifier_edittext);
        miscModifierText = (EditText) findViewById(R.id.misc_modifier_edittext);

        btnSaveButton = (Button) findViewById(R.id.save_button);
        
        mRowId = (savedInstanceState == null) ? null :
            (Long) savedInstanceState.getSerializable(SkillsTable2.KEY_ID);
		if (mRowId == null) {
			Bundle extras = getIntent().getExtras();
			mRowId = extras != null ? extras.getLong(SkillsTable2.KEY_ID)
									: null;
		}
		        
		populateFields();
		
        btnSaveButton.setOnClickListener(new View.OnClickListener() {
          	 
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
        
	}
	
	@Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveState();
        outState.putSerializable(SkillsTable2.KEY_ID, mRowId);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateFields();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
   
        mDbHelper.close();
    }
    
    private void saveState() {
        String total_bonus = totalBonusText.getText().toString();
        String ability_modifier = abilityModifierText.getText().toString();
        String ranksModifier = ranksModifierText.getText().toString();
        String miscModifier = miscModifierText.getText().toString();

        mDbHelper.updateSkill(mRowId, total_bonus, ability_modifier, ranksModifier, miscModifier);
    }
	
	private void populateFields() {
        if (mRowId != null) {

        	Cursor skill = mDbHelper.fetchSkills(mRowId);
            startManagingCursor(skill);
            totalBonusText.setText(skill.getString(
            		skill.getColumnIndexOrThrow(SkillsTable2.KEY_TOTAL_BONUS)));
            abilityModifierText.setText(skill.getString(
            		skill.getColumnIndexOrThrow(SkillsTable2.KEY_ABILITY_MOD)));
            ranksModifierText.setText(skill.getString(
            		skill.getColumnIndexOrThrow(SkillsTable2.KEY_RANK)));
            miscModifierText.setText(skill.getString(
            		skill.getColumnIndexOrThrow(SkillsTable2.KEY_MISC_MODIFIER)));
            setTitle(skill.getString(
            		skill.getColumnIndexOrThrow(SkillsTable2.KEY_SKILL_NAME)));

        }
    }
	

}
