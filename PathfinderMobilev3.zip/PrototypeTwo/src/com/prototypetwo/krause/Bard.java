package com.prototypetwo.krause;

public class Bard extends ProClass {
	
	public Bard()
	{
		super();
		this.alignment = new String[] { "Chaotic Evil", "Chaotic Neutral", "Chaotic Good", "Neutral Evil","Neutral", "Neutral Good", "Lawful Evil", "Lawful Neutral", "Lawful Good" };
		this.hitDie = 8;
		this.skills= new String[] {"Acrobatics","Appraise","Bluff","Climb","Diplomacy","Disguise","Escape Artist",
									"Intimidate","Knowledge-Arcana","Knowledge-Dungeoneering","Knowledge-Engineering",
									"Knowledge-Geography","Knowledge-History","Knowledge-Local","Knowledge-Nature",
									"Knowledge-Nobility","Knowledge-Planes","Knowledge-Religion","Linguistics","Perception",
									"Perform","Profession","Sense Motive","Sleight of Hand","Spellcraft","Stealth","Use Magic Device"};
		this.skillRanks =6;
	}

}
