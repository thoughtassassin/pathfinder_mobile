package com.prototypetwo.krause;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

public class FeatsTable2 extends SQLiteOpenHelper {
	
    // All Static variables
    // Database Version
    public static final int DATABASE_VERSION = 1;
 
    // Database Name
    public static final String DATABASE_NAME = "FeatsInfo2";
 
    // Feats table name
    public static final String TABLE_FEATS = "FeatsTable2";
 
    //Feats Table Columns names
    public static final String KEY_ID = "_id";
    public static final String KEY_C_ID = "c_id";
    public static final String KEY_FEAT_ID = "f_id";
    
    //Feats table list
    public static final String TABLE_FEATS_LIST = "FeatsList";
   
    //Feats List Table Columns names
    public static final String KEY_NAME = "name";
    public static final String KEY_DESCRIPTION = "description";
    
    //database for our class
    private SQLiteDatabase db;
    
	public FeatsTable2(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		String CREATE_FEATS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_FEATS + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_C_ID + " INTEGER,"
                + KEY_FEAT_ID + " INTEGER " + ")";
		
		String CREATE_FEATS_LIST = "CREATE TABLE IF NOT EXISTS " + TABLE_FEATS_LIST + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_NAME + " TEXT,"
                + KEY_DESCRIPTION + " TEXT " + ")";
		
		db.execSQL(CREATE_FEATS_TABLE);
		db.execSQL(CREATE_FEATS_LIST);
		
	}

	 // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FEATS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FEATS_LIST);
 
        // Create tables again
        onCreate(db);
    }
    
    //open db
  	public SQLiteDatabase open() throws SQLException
  	{
  		return db = this.getWritableDatabase();
  	}
  	
  	//close db
  	 public void close()
  	 {
  		 db.close();
  		 
  	 }
  	 
     //Fill feats table with data
     public void addFeatsList() {
    	 
    if (!checkFeatsListExists())
    {
    	 
		 String sqlString = "INSERT INTO 'FeatsList'" +
				 "SELECT '1' AS '_id', 'Acrobatic' AS 'name', '+2 bonus on Acrobatics and Fly checks' AS 'description'" +
				 " UNION SELECT '2', 'Agile Maneuvers', 'Use your Dex bonus when calculating your CMB'" +
				 " UNION SELECT '3', 'Alertness', '+2 bonus on Perception and Sense Motive checks'" +
				 " UNION SELECT '4', 'Alignment Channel', 'Channel energy can heal or harm outsiders'" +
				 " UNION SELECT '5', 'Animal Affinity', '+2 bonus on Handle Animal and Ride checks'" +
				 " UNION SELECT '6', 'Arcane Armor Training', 'Reduce your arcane spell failure chance by 10%'" +
				 " UNION SELECT '7', 'Arcane Armor Mastery', 'Reduce your arcane spell failure chance by 20%'" +
				 " UNION SELECT '8', 'Arcane Strike', '+1 damage and weapons are considered magic'" +
				 " UNION SELECT '9', 'Armor Proficiency', 'No penalties on attack rolls while wearing armor'" +
				 " UNION SELECT '10', 'Athletic', '+2 bonus on Climb and Swim checks'" +
				 " UNION SELECT '11', 'Augment Summoning', 'Summoned creatures gain +4 Str and Con'" +
				 " UNION SELECT '12', 'Blind-Fight', 'Reroll miss chances for concealment'" +
				 " UNION SELECT '13', 'Catch Off-Guard', 'No penalties for improvised melee weapons'" +
				 " UNION SELECT '14', 'Channel Smite', 'Channel energy through your attack'" +
				 " UNION SELECT '15', 'Combat Casting', '+4 bonus on concentration checks for defensive casting'" +
				 " UNION SELECT '16', 'Combat Expertise', 'Trade attack bonus for AC bonus'" +
				 " UNION SELECT '17', 'Command Undead', 'Channel energy can be used to control undead'" +
				 " UNION SELECT '18', 'Critical Focus', '+4 bonus on attack rolls made to confirm critical hits'" +
				 " UNION SELECT '19', 'Deadly Aim', 'Trade ranged attack bonus for damage'" +
				 " UNION SELECT '20', 'Deceitful', '+2 bonus on Bluff and Disguise checks'" +
				 " UNION SELECT '21', 'Defensive Combat Training', 'Use your total Hit Dice as your base attack bonus for CMD'" +
				 " UNION SELECT '22', 'Deft Hands', '+2 bonus on Disable Device and Sleight of Hand checks'" +
				 " UNION SELECT '23', 'Disruptive', 'Increases the DC to cast spells adjacent to you'" +
				 " UNION SELECT '24', 'Elemental Channel', 'Channel energy can harm or heal elementals'" +
				 " UNION SELECT '25', 'Endurance', '+4 bonus on checks to avoid nonlethal damage'" +
				 " UNION SELECT '26', 'Eschew Materials', 'Cast spells without material components'" +
				 " UNION SELECT '27', 'Exotic Weapon Proficiency', 'No penalty on attacks made with one exotic weapon'" +
				 " UNION SELECT '28', 'Extra Channel', 'Channel energy two additional times per day'" +
				 " UNION SELECT '29', 'Extra Ki', 'Increase your ki pool by 2 points'" +
				 " UNION SELECT '30', 'Extra Lay On Hands', 'Use lay on hands two additional times per day'" +
				 " UNION SELECT '31', 'Extra Mercy', 'Your lay on hands benefits from one additional mercy'" +
				 " UNION SELECT '32', 'Extra Performance', 'Use bardic performance for 6 additional rounds per day'" +
				 " UNION SELECT '33', 'Extra Rage', 'Use rage for 6 additional rounds per day'" +
				 " UNION SELECT '34', 'Fleet', 'Your base speed increases by 5 feet'" +
				 " UNION SELECT '35', 'Great Fortitude', '+2 on Fortitude saves'" +
				 " UNION SELECT '36', 'Improved Great Fortitude', 'Once per day, you may reroll a Fortitude save'" +
				 " UNION SELECT '37', 'Improved Channel', '+2 bonus on channel energy DC'" +
				 " UNION SELECT '38', 'Improved Counterspell', 'Counterspell with spell of the same school'" +
				 " UNION SELECT '39', 'Improved Critical', 'Double the threat range of one weapon'" +
				 " UNION SELECT '40', 'Improved Familiar', 'Gain a more powerful familiar'" +
				 " UNION SELECT '41', 'Improved Initiative', '+4 bonus on initiative checks'" +
				 " UNION SELECT '42', 'Improved Unarmed Strike', 'Always considered armed'" +
				 " UNION SELECT '43', 'Improvised Weapon Mastery', 'Make an improvised weapon deadly'" +
				 " UNION SELECT '44', 'Intimidating Prowess', 'Add Str to Intimidate in addition to Cha'" +
				 " UNION SELECT '45', 'Iron Will', '+2 bonus on Will saves'" +
				 " UNION SELECT '46', 'Improved Iron Will', 'Once per day, you may reroll a Will save'" +
				 " UNION SELECT '47', 'Leadership', 'Gain a cohort and followers'" +
				 " UNION SELECT '48', 'Lightning Reflexes', '+2 bonus on Reflex saves'" +
				 " UNION SELECT '49', 'Improved Lightning Reflexes', 'Once per day, you may reroll a Reflex save'" +
				 " UNION SELECT '50', 'Lunge', 'Take a �2 penalty to your AC to attack with reach'" +
				 " UNION SELECT '51', 'Magical Aptitude', '+2 bonus on Spellcraft and Use Magic Device checks'" +
				 " UNION SELECT '52', 'Martial Weapon Proficiency', 'No penalty on attacks made with one martial weapon'" +
				 " UNION SELECT '53', 'Master Craftsman', 'You can craft magic items without being a spellcaster'" +
				 " UNION SELECT '54', 'Mounted Combat', 'Avoid attacks on mount with Ride check'" +
				 " UNION SELECT '55', 'Natural Spell', 'Cast spells while using wild shape'" +
				 " UNION SELECT '56', 'Nimble Moves', 'Ignore 5 feet of difficult terrain when you move'" +
				 " UNION SELECT '57', 'Persuasive', '+2 bonus on Diplomacy and Intimidate checks'" +
				 " UNION SELECT '58', 'Point-Blank Shot', '+1 attack and damage on targets within 30 feet'" +
				 " UNION SELECT '59', 'Power Attack', 'Trade melee attack bonus for damage'" +
				 " UNION SELECT '60', 'Quick Draw', 'Draw weapon as a free action'" +
				 " UNION SELECT '61', 'Rapid Reload', 'Reload crossbow quickly'" +
				 " UNION SELECT '62', 'Run', 'Run at 5 times your normal speed'" +
				 " UNION SELECT '63', 'SELECT '',ive Channeling', 'Choose whom to affect with channel energy'" +
				 " UNION SELECT '64', 'Self-Sufficient', '+2 bonus on Heal and Survival checks'" +
				 " UNION SELECT '65', 'Shield Proficiency', 'No penalties on attack rolls when using a shield'" +
				 " UNION SELECT '66', 'Simple Weapon Proficiency', 'No penalty on attacks made with simple weapons'" +
				 " UNION SELECT '67', 'Skill Focus', '+3 bonus on one skill UNION SELECT '', +6 at 10 ranks)'" +
				 " UNION SELECT '68', 'Spell Focus', '+1 bonus on save DCs for one school'" +
				 " UNION SELECT '69', 'Spell Mastery', 'Prepare some spells without a spellbook'" +
				 " UNION SELECT '70', 'Spell Penetration', '+2 bonus on level checks to beat spell resistance'" +
				 " UNION SELECT '71', 'Stealthy', '+2 bonus on Escape Artist and Stealth checks'" +
				 " UNION SELECT '72', 'Step Up', 'Take a 5-foot step as an immediate action'" +
				 " UNION SELECT '73', 'Strike Back', 'Attack foes that strike you while using reach'" +
				 " UNION SELECT '74', 'Throw Anything', 'No penalties for improvised ranged weapons'" +
				 " UNION SELECT '75', 'Toughness', '+3 hit points, +1 per Hit Die beyond 3'" +
				 " UNION SELECT '76', 'Turn Undead', 'Channel energy can be used to make undead flee'" +
				 " UNION SELECT '77', 'Two-Weapon Fighting', 'Reduce two-weapon fighting penalties'" +
				 " UNION SELECT '78', 'Weapon Finesse', 'Use Dex instead of Str on attack rolls with light weapons'" +
				 " UNION SELECT '79', 'Weapon Focus', '+1 bonus on attack rolls with one weapon'";
		 
	    	 db.execSQL(sqlString);
	 	 
         }

     }
    
    // Adding feat for character
    public void addFeat(String c_id, String f_id) {
    	   
    		if (!featExists(c_id, f_id))
    		{
    		
	    	   ContentValues values = new ContentValues();
	    	   values.put(KEY_C_ID, c_id); // Character Name
	    	   values.put(KEY_FEAT_ID, f_id); // Character Race   
	    	 
	    	   // Inserting Row
	    	   db.insert(TABLE_FEATS, null, values);
  
    		}
    	
    }
    
    //delete Feats
    public void deleteFeats(String id) {
        
    	if (recordExists(id))
    	{
	        db.delete(TABLE_FEATS, KEY_ID + " = ?",
	                new String[] { id });
    	}
    }
    
   //Cursor to retrieves data from Feats List
    public Cursor getFeatsCursor()
    {
    	
    	SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
    	
    	queryBuilder.setTables(TABLE_FEATS_LIST);
    	String[] asColumnsToReturn = new String[] { KEY_ID, KEY_NAME, KEY_DESCRIPTION };
    	
    	Cursor mCursor = queryBuilder.query(db, asColumnsToReturn, null, null, null, null, "name ASC");
    	
    	return mCursor;
    }
    
    //Cursor to retrieves data from Feats List
    public Cursor myFeatsCursor(String c_id)
    {
    	
    	Cursor mCursor = db.rawQuery("SELECT FeatsTable2._id, name, description FROM FeatsList, FeatsTable2 WHERE " +
    			"FeatsList._id=FeatsTable2.f_id AND FeatsTable2.c_id=?", new String[] { c_id } );
    	
    	return mCursor;
    }
    
    
    
    public boolean recordExists(String id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_FEATS +" WHERE _id=?", 
		        new String[] { id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}
    
    public boolean featExists(String c_id, String f_id)
   	{
   	
   	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_FEATS +" WHERE c_id=? AND f_id=?", 
   		        new String[] { c_id, f_id });
   	  boolean exists = (cursor.getCount() > 0);
   	  cursor.close();
   	  
   	  return exists;
   		
   	}
    
    public boolean checkFeatsListExists()
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_FEATS_LIST, 
		        null);
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}
    
    public boolean characterRecordExists(String id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_FEATS +" WHERE c_id=?", 
		        new String[] { id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}
    
  //delete all gear
    public void deleteAllFeats(String c_id) {
        
    	if (characterRecordExists(c_id))
    	{
	        db.delete(TABLE_FEATS, KEY_C_ID + " = ?",
	                new String[] { c_id });
    	}
    }

}
