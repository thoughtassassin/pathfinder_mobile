package com.prototypetwo.krause;

import android.net.Uri;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.ListActivity;
import android.app.ActionBar.OnNavigationListener;
import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class SkillsActivity2 extends ListActivity {
	
	public Cursor cursor;
	private Cursor skillsCursor;
	public ListView skillsList;
	public String[] characterAttributes;
	public String characterClass;
	public String characterName;
	public String[][] characterClassArray;
	public String[][] skills;
	public String[] characterAbilities; //Save abilities prior to modifiers by race
	public String[] characterBio; //Keeps track of biographical info
	private SkillsTable2 mDbHelper;
	private BioTable character;
	private AbilitiesTable characterAttributesTable; //stores abilities
	private String c_id;
	public String initalValue = "0";
	private static final int ACTIVITY_EDIT=1;
	private OnNavigationListener mOnNavigationListener; //navigation listener
	private String[] menuItems = new String[] {
    		"Menu",
    		"Characters",
    		"Bio",
            "Abilities",
            "Skills",
            "Feats",
            "Gear",
            "Other",
            "Board",
            "Chat"
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.skills_screen);
        setTitle(R.string.skills_screen);
        
        character = new BioTable(this);
        characterAttributesTable = new AbilitiesTable(this);
        
        character.open();
        characterAttributesTable.open();
       
        //get the id from previous screen
        c_id = getIntent().getExtras().get("c_id").toString();
        
        Button btnSaveButton = (Button) findViewById(R.id.next_button);
        
        //get character Bio Info from database
        characterBio = character.getBio(c_id);
        characterClass = characterBio[2]; //character class
        
        //get character Abilities
    	characterAbilities = characterAttributesTable.getAbilities(c_id); //Store original
        
        //list of skills
        skills = new String[][]{ 
        	{"Acrobatics", "=Dex*", "1"},
        	{"Appraise", "=Int", "3"},
        	{"Bluff", "=Cha", "5"},
        	{"Climb", "=Str*", "0"},
        	{"Craft", "=Int", "3"},
        	{"Diplomacy", "=Cha", "3"},
        	{"Disable Device", "=Dex*", "1"},
        	{"Disguise", "=Cha", "5"},
        	{"Escape Artist", "=Dex*", "1"},
        	{"Fly", "=Dex*", "1"},
        	{"Handle Animal", "=Cha", "5"},
        	{"Heal", "=Wis", "4"},
        	{"Intimidate", "=Cha", "5"},
        	{"Knowledge-Arcana", "=Int", "3"},
        	{"Knowledge-Dungeoneering", "=Int", "3"},
        	{"Knowledge-Engineering", "=Int", "3"},
        	{"Knowledge-Geography", "=Int", "3"},
        	{"Knowledge-History", "=Int", "3"},
        	{"Knowledge-Local", "=Int", "3"},
        	{"Knowledge-Nature", "=Int", "3"},
        	{"Knowledge-Nobility", "=Int", "3"},
        	{"Knowledge-Planes", "=Int", "3"},
        	{"Knowledge-Religion", "=Int", "3"},
        	{"Linguistics", "=Int", "3"},
        	{"Perception", "=Wis", "4"},
        	{"Perform", "=Cha", "5"},
        	{"Profession", "=Wis", "4"},
        	{"Ride", "=Dex*", "1"},
        	{"Sense Motive", "=Wis", "4"},
        	{"Sleight of Hand", "=Dex*", "1"},
        	{"Spellcraft", "=Int", "3"},
        	{"Stealth", "=Dex*", "1"},
        	{"Survival", "=Wis", "4"},
        	{"Swim", "=Str*", "0"},
        	{"Use Magic Device", "=Cha", "5"} };
        
        
        mDbHelper = new SkillsTable2(this);
        mDbHelper.open();
        
        //Initialize modified abilities row
        if (mDbHelper.recordExists(c_id))
        {
        	fillData();
        }
        else
        {
        	for (int i = 0; i < skills.length; i++ )
        	{
        	 
        		int abilityIndex = Integer.parseInt(skills[i][2]);
            	int abilityScore = Integer.parseInt(characterAbilities[abilityIndex]);
            	String abilityMod = String.valueOf( (abilityScore/2)-5 );
            	String totalBonusScore = String.valueOf((abilityScore/2)-5);
        		
        		mDbHelper.addSkills(c_id, skills[i][0], totalBonusScore, abilityMod, skills[i][1], "0", "0");
        	 
        	}
        	
        	fillData();

        }
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, menuItems);
        
        /** Enabling dropdown list navigation for the action bar */
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
 
        /** Defining Navigation listener */
        ActionBar.OnNavigationListener navigationListener = new OnNavigationListener() {
 
            @Override
            public boolean onNavigationItemSelected(int itemPosition, long itemId) {
                
            	if (itemPosition == 1)
            	{
            		Intent i = new Intent(getApplicationContext(), OpenScreenActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 2)
            	{
            		Intent i = new Intent(getApplicationContext(), BioActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 3)
            	{
            		Intent i = new Intent(getApplicationContext(), AbilityActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 4)
            	{
            		Intent i = new Intent(getApplicationContext(), SkillsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 5)
            	{
            		Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 6)
            	{
            		Intent i = new Intent(getApplicationContext(), GearActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 7)
            	{
            		Intent i = new Intent(getApplicationContext(), OtherActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 8)
            	{
            		Intent i = new Intent(getApplicationContext(), UpdatePositionActivity.class);
                    i.putExtra( "c_id", c_id );
                    startActivity(i);
                    closeConnections();
            	}
            	else if (itemPosition == 9)
            	{
            		Intent sendIntent = new Intent(Intent.ACTION_VIEW);         
            		sendIntent.setData(Uri.parse("sms:"));
            		startActivity(sendIntent);
                    closeConnections();
            	}
            	
            	
                return false;
            }
        };
 
        /** Setting dropdown items and item navigation listener for the actionbar */
        getActionBar().setListNavigationCallbacks(adapter, navigationListener);
        
        registerForContextMenu(getListView());
                
        btnSaveButton.setOnClickListener(new View.OnClickListener() {
       	 
            @Override
            public void onClick(View view) {
            	
            	// Launching Bio Screen
                Intent i = new Intent(getApplicationContext(), FeatsActivity2.class);
                i.putExtra( "c_id", String.valueOf( c_id ) );
                startActivity(i);
            	
            }
        });
        
    }
    
    private void fillData() {
        skillsCursor = mDbHelper.fetchAllSkills(c_id);
        startManagingCursor(skillsCursor);

        // Create an array to specify the fields we want to display in the list (only TITLE)
        String[] from = new String[]{SkillsTable2.KEY_SKILL_NAME, SkillsTable2.KEY_TOTAL_BONUS,
        		SkillsTable2.KEY_ABILITY_MOD, SkillsTable2.KEY_ABILITY_MOD_LABEL,
        		SkillsTable2.KEY_RANK, SkillsTable2.KEY_MISC_MODIFIER};

        // and an array of the fields we want to bind those fields to (in this case just text1)
        int[] to = new int[] { R.id.skillsName, R.id.total_bonus,  R.id.ability_mod, R.id.ability_mod_label,
        		R.id.ranks, R.id.misc_mod};

        // Now create a simple cursor adapter and set it to display
        SimpleCursorAdapter skills = 
            new SimpleCursorAdapter(this, R.layout.skillsrow, skillsCursor, from, to);
        setListAdapter(skills);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        
        Intent i = new Intent(this, SkillActivityEdit.class);
        i.putExtra(SkillsTable2.KEY_ID, id);
        i.putExtra( "title", SkillsTable2.KEY_SKILL_NAME );
        startActivityForResult(i, ACTIVITY_EDIT);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        closeConnections();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        character.open();
        characterAttributesTable.open();
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        character.open();
        characterAttributesTable.open();
        fillData();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeConnections();

    }
    
    protected void closeConnections()
    {
    	character.close();
        characterAttributesTable.close();
    }
    

}