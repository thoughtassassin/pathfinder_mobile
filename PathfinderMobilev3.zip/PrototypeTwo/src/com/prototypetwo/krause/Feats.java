package com.prototypetwo.krause;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class Feats extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feats_page);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_feats, menu);
        return true;
    }
}
