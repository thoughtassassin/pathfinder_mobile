package com.prototypetwo.krause;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ArmorTable extends SQLiteOpenHelper {
	
	 // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "ArmorInfo";
 
    // Size table name
    private static final String TABLE_ARMOR = "ArmorTable";
 
    // Size Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_C_ID = "c_id";
    private static final String KEY_ARMOR_BONUS= "armor_bonus";
    private static final String KEY_SHEILD_BONUS = "sheild_bonus";
    private static final String KEY_SRE_MODIFIER = "sre_modifier";
    private static final String KEY_NATURAL_ARMOR = "natural_armor";
    private static final String KEY_DEFLECTION_MODIFIER= "deflection_modifier";
    private static final String KEY_MISC_MODIFIER= "misc_modifier";
    private static final String KEY_TOUCH= "touch";
    private static final String KEY_FLAT_FOOTED= "flat_footed";

    public ArmorTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub

}
    
public void onCreate(SQLiteDatabase db) {
		
		String CREATE_ARMOR_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_ARMOR + " ("
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ KEY_C_ID + " INTEGER, "
				+ KEY_ARMOR_BONUS + " INTEGER, "
				+ KEY_SHEILD_BONUS + " INTEGER, "
				+ KEY_SRE_MODIFIER + " INTEGER, "
				+ KEY_DEFLECTION_MODIFIER + " INTEGER, "
				+ KEY_MISC_MODIFIER + " INTEGER, "
				+ KEY_TOUCH + " INTEGER, "
				+ KEY_FLAT_FOOTED + " INTEGER " + ")";
        db.execSQL(CREATE_ARMOR_TABLE);
		
	}

public SQLiteDatabase databaseName()
{
	return this.getWritableDatabase();
}


 // Upgrading database
@Override
public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    // Drop older Abilities table if existed
    db.execSQL("DROP TABLE IF EXISTS " + TABLE_ARMOR);

    // Create tables again
    onCreate(db);
    
}

public long addArmor(String c_id, String armor_bonus, String sheild_bonus, String sre_modifier, String natural_armor,
		String deflection_modifier, String misc_modifier, String touch, String flat_footed ) {
	
	   SQLiteDatabase db = this.getWritableDatabase();
	   
	   ContentValues values = new ContentValues();
	   values.put(KEY_C_ID, c_id);
	   values.put(KEY_ARMOR_BONUS, armor_bonus);
	   values.put(KEY_SHEILD_BONUS,sheild_bonus); 
	   values.put(KEY_SRE_MODIFIER, sre_modifier); 
	   values.put(KEY_NATURAL_ARMOR, natural_armor);   
	   values.put(KEY_DEFLECTION_MODIFIER,deflection_modifier);
	   values.put(KEY_MISC_MODIFIER, misc_modifier);
	   values.put(KEY_TOUCH, touch); 
	   values.put(KEY_FLAT_FOOTED,flat_footed); 
	 
	   // Inserting Row
	   long insertID = db.insert(TABLE_ARMOR, null, values);
	   db.close(); // Closing database connection
	   
	   return insertID;
}

//Getting Character Abilities Attributes
public String[] getArmor(String characterID) {
 
	SQLiteDatabase db = this.getReadableDatabase();
	String[] characterArmor = new String[8];
 
 Cursor cursor = db.query(TABLE_ARMOR, new String[] { KEY_C_ID, KEY_ARMOR_BONUS, KEY_SHEILD_BONUS,KEY_SRE_MODIFIER,
		 KEY_NATURAL_ARMOR,KEY_DEFLECTION_MODIFIER,KEY_MISC_MODIFIER,KEY_TOUCH, KEY_FLAT_FOOTED }, KEY_ID + "=?",
         new String[] { characterID }, null, null, null, null);
 
 if (cursor.moveToFirst())
 {
     //enter character attributes into string
     for (int i = 0; i < characterArmor.length; i++ )
     {
     	characterArmor[i] = cursor.getString(i);
     }
 }
 
return characterArmor;
         
}

public int updateArmor(String c_id, String armor_bonus, String sheild_bonus, String sre_modifier, String natural_armor,
		String deflection_modifier, String misc_modifier, String touch, String flat_footed ) {
    
	SQLiteDatabase db = this.getWritableDatabase();
 
    ContentValues values = new ContentValues();
       values.put(KEY_C_ID, c_id);
	   values.put(KEY_ARMOR_BONUS, armor_bonus);
	   values.put(KEY_SHEILD_BONUS,sheild_bonus); 
	   values.put(KEY_SRE_MODIFIER, sre_modifier); 
	   values.put(KEY_NATURAL_ARMOR, natural_armor);   
	   values.put(KEY_DEFLECTION_MODIFIER,deflection_modifier);
	   values.put(KEY_MISC_MODIFIER, misc_modifier);
	   values.put(KEY_TOUCH, touch); 
	   values.put(KEY_FLAT_FOOTED,flat_footed); 
	   
    // updating row
    return db.update(TABLE_ARMOR, values, KEY_C_ID + " = ?",
            new String[] { c_id });
}

public boolean recordExists(String c_id)
{

  SQLiteDatabase db = this.getReadableDatabase();
  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_ARMOR +" WHERE c_id=?", 
	        new String[] { c_id });
  boolean exists = (cursor.getCount() > 0);
  cursor.close();
  
  return exists;
	
}



}

