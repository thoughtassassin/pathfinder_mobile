package com.prototypetwo.krause;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class AbilitiesTable extends SQLiteOpenHelper {
	
	// All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "AbilitiesInfo";
 
    // Abilities table name
    private static final String TABLE_ABILITIES = "AbilitiesTable";
 
    // Abilities Table Columns names
    private static final String KEY_ID = "_id";
    private static final String KEY_C_ID = "c_id";
    private static final String KEY_STRENGTH = "strength";
    private static final String KEY_DEXTERITY = "dexterity";
    private static final String KEY_CONSTITUTION = "constitution";
    private static final String KEY_INTELLIGENCE = "intelligence";
    private static final String KEY_WISDOM = "wisdom";
    private static final String KEY_CHARISMA = "charisma";
    
   //database for our class
   private SQLiteDatabase db;
    
    public AbilitiesTable(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub

	}
	    
	public void onCreate(SQLiteDatabase db) {
			
			String CREATE_ABILITIES_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_ABILITIES + " ("
					+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
					+ KEY_C_ID + " INTEGER, "
					+ KEY_STRENGTH+ " INTEGER, "
					+ KEY_DEXTERITY+ " INTEGER, "
					+ KEY_CONSTITUTION + " INTEGER, "
					+ KEY_INTELLIGENCE + " INTEGER, "
					+ KEY_WISDOM + " INTEGER, "
					+ KEY_CHARISMA + " INTEGER " + ")";
	        db.execSQL(CREATE_ABILITIES_TABLE);
			
		}
	
	 // Upgrading database
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	    // Drop older Abilities table if existed
	    db.execSQL("DROP TABLE IF EXISTS " + TABLE_ABILITIES);
	
	    // Create tables again
	    onCreate(db);
	    
	}
	
	//open db
	public SQLiteDatabase open() throws SQLException
	{
		return db = this.getWritableDatabase();
	}
	
	//close db
	 public void close()
	 {
		 db.close();
		 
	 }
	
	//Adding abilities for character
	public long addAbilities(String c_id, String strength, String dexterity, String constitution, String intelligence,
			String wisdom, String charisma) {
		
		   ContentValues values = new ContentValues();
		   values.put(KEY_C_ID, c_id);
		   values.put(KEY_STRENGTH, strength);
		   values.put(KEY_DEXTERITY, dexterity); 
		   values.put(KEY_CONSTITUTION, constitution); 
		   values.put(KEY_INTELLIGENCE, intelligence);
		   values.put(KEY_WISDOM, wisdom);
		   values.put(KEY_CHARISMA, charisma);
		 
		   // Inserting Row
		   long insertID = db.insert(TABLE_ABILITIES, null, values);
		   
		   return insertID;
		
	}
	
	// Getting Character Abilities Attributes
	public String[] getAbilities(String characterID) {
	    
		String[] characterAttributes = new String[6];
	    
	    Cursor cursor = db.query(TABLE_ABILITIES, new String[] { KEY_STRENGTH, KEY_DEXTERITY, KEY_CONSTITUTION,
	    		KEY_INTELLIGENCE, KEY_WISDOM, KEY_CHARISMA }, KEY_C_ID + "=?",
	            new String[] { characterID }, null, null, null, null);
	    
	    if (cursor.moveToFirst())
	    {
	        //enter character attributes into string
	        for (int i = 0; i < characterAttributes.length; i++ )
	        {
	        	characterAttributes[i] = cursor.getString(i);
	        }
	    }
	    
	   return characterAttributes;
	            
	}
	
	//update Abilities
	public int updateAbilities(String c_id, String strength, String dexterity, String constitution, String intelligence,
			String wisdom, String charisma) {
	    	 
	    ContentValues values = new ContentValues();
	    values.put(KEY_STRENGTH, strength);
	    values.put(KEY_DEXTERITY, dexterity); 
	    values.put(KEY_CONSTITUTION, constitution); 
	    values.put(KEY_INTELLIGENCE, intelligence);
	    values.put(KEY_WISDOM, wisdom); 
	    values.put(KEY_CHARISMA, charisma); 
	 
	    // updating row
	    return db.update(TABLE_ABILITIES, values, KEY_C_ID + " = ?",
	            new String[] { c_id });
	}
	
	//delete Abilities
    public void deleteAbilities(String c_id) {
        
    	if (recordExists(c_id))
    	{
	        db.delete(TABLE_ABILITIES, KEY_C_ID + " = ?",
	                new String[] { c_id });
    	}
    }
	
	public boolean recordExists(String c_id)
	{
	
	  Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_ABILITIES +" WHERE c_id=?", 
		        new String[] { c_id });
	  boolean exists = (cursor.getCount() > 0);
	  cursor.close();
	  
	  return exists;
		
	}

}